import tensorflow as tf
import lib.config.config_1BSNt_KUENr as cfg
import lib.utils.communication_tools as ct
import communication_tools_taojiyun as cttjy
# import lib.network.network_fully_digital_beamforming as net
import lib.network.network_1BSNt_KUENr as net
import lib.utils.SaveAndLoad as sal
import matplotlib.pyplot as plt
import numpy as np
import os
import scipy.io as sio
import datetime as date


def test(model, sess, data_generator, channel, parameters):
    n_frames = int(cfg.FLAGS.N_bits_test/data_generator.bit/cfg.FLAGS.Ns)
    test_result ={}
    BER = {}
    x = []
    y = []
    # SNR = [10]
    for snr in range(-10, 0, 1):
        _, batch_x, _, scatter_std = data_generator.signal_generator([n_frames, model.Ns_total])
        batch_noise = data_generator.noise_generator(1, snr, [n_frames, model.Nr_total])
        batch_h = channel

        feed_dict = {model.real_x: np.float32(np.real(batch_x)),
                     model.imag_x: np.float32(np.imag(batch_x)),
                     model.real_h: np.float32(np.real(batch_h)),
                     model.imag_h: np.float32(np.imag(batch_h)),
                     model.real_noise: np.float32(np.real(batch_noise)),
                     model.imag_noise: np.float32(np.imag(batch_noise))
                     }
        input_tensors = [parameters]
        result = sess.run(input_tensors, feed_dict)
        result = result[0]

        # Frf
        theta_t = np.zeros((model.Ns_total, cfg.FLAGS.Nt), dtype=np.float32)
        Frf = np.zeros((model.Ns_total, cfg.FLAGS.Nt), dtype=np.complex64)

        t = np.squeeze(result["rf_beamforming/Variable:0"])
        theta_t[0, 0:model.t_per] = t
        complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in t])[np.newaxis, :]
        Frf[0, 0:model.t_per] = complex_temp
        for index in range(1, model.Ns_total):
            t = np.squeeze(result["rf_beamforming/Variable_"+str(index)+":0"])
            theta_t[index, index * model.t_per: (index + 1) * model.t_per] = t
            complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in t])[np.newaxis, :]
            Frf[index, index * model.t_per: (index + 1) * model.t_per] = complex_temp

        # Wrf
        theta_r = np.zeros((model.Nr_total, model.Nrrf*model.K), dtype=np.float32)
        Wrf = np.zeros((model.Nr_total, model.Nrrf*model.K), dtype=np.complex64)

        for user in range(cfg.FLAGS.K):
            r = np.squeeze(result["user"+str(user)+"/rf_combining/Variable:0"])
            TT = theta_r[user * model.Nr:user * model.Nr + model.r_per, user * model.Ns]
            theta_r[user * model.Nr:user * model.Nr + model.r_per, user * model.Ns] = r
            complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in r])[np.newaxis, :]
            Wrf[user*model.Nr:user*model.Nr + model.r_per, user*model.Ns] = complex_temp
            if cfg.FLAGS.Ns != 1:
                for i in range(1, model.Ns):
                    r = np.squeeze(result["user"+str(user)+"/rf_combining/Variable_" + str(i) + ":0"])
                    theta_r[user*model.Nr+i*model.r_per:user*model.Nr+(i+1)*model.r_per, user*model.Ns + i] = r
                    complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in r])[np.newaxis, :]
                    Wrf[user * model.Nr + i * model.r_per:user * model.Nr + (i + 1) * model.r_per, user * model.Ns + i] = complex_temp
        H1 = np.matmul(Frf, batch_h)
        h_eq = np.matmul(H1, Wrf)
        print("djcsjdc")
        pass



def main():
    # built model
    model = net.Cdnn()
    print(cfg.FLAGS.connected)
    print("System parameters:")
    print("K=%d, Ns=%d, Ntrf=%d, Nrrf=%d, Nt=%d, Nr=%d" % (model.K, model.Ns, model.Ntrf, model.Nrrf, model.Nt, model.Nr))
    # print("Network parameters:")
    # print("digital beamformer:", str(model.db_dim_list))
    # print("digital combiner:", str(model.dc_dim_list))
    model.summary_op = tf.summary.merge_all()

    saver = tf.train.Saver(tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES), max_to_keep=1)
    sess = tf.InteractiveSession()

    resume_itr = 0

    tf.global_variables_initializer().run()
    tf.train.start_queue_runners()

    data_generator = cttjy.signal(cfg.FLAGS.modulation_mode, cfg.FLAGS.power_normalization, model.Ns)
    if cfg.FLAGS.resume or not cfg.FLAGS.train:
        model_file = tf.train.latest_checkpoint(cfg.FLAGS.logdir)
        if model_file:
            ind1 = model_file.index('model')
            resume_itr = int(model_file[ind1+5:])
            print("Restoring model weights from " + model_file)
            saver.restore(sess, model_file)

    variable_name = [v.name for v in tf.trainable_variables()]
    parameters = {}
    for v_name in variable_name:
        parameters[v_name] = tf.get_default_graph().get_tensor_by_name(v_name)

    hsets = sal.load_pkl(cfg.FLAGS.path_for_hsets)
    test(model, sess, data_generator, hsets["mimochan0"], parameters)


if __name__ == "__main__":
    # tf.set_random_seed(1024)
    # np.random.seed(1024)
    if not os.access("data/HB/"+cfg.FLAGS.connected, os.F_OK):
        os.makedirs("data/HB/" + cfg.FLAGS.connected)

    cfg.FLAGS.path_for_hsets = "data/HB/"+cfg.FLAGS.connected+"/hsets.pkl"
    cfg.FLAGS.logdir = "data/HB/"+cfg.FLAGS.connected+"/logdir"
    cfg.FLAGS.path_for_ber = "data/HB/"+cfg.FLAGS.connected+"/ber.pkl"
    # data = load()
    main()