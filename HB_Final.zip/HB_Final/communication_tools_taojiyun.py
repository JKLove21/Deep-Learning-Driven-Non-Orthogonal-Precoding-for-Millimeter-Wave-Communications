import numpy as np
import tensorflow as tf
from functools import reduce
import itertools as iter


def signal_power(signal_input, *arg):
    """
    Calculate the power of the input signal, default axis=0
    :param signal_input:
    :param arg:
                arg[0]: axis
    :return: power
    """
    signal_T = np.array(signal_input)
    energy = np.abs(signal_T) ** 2
    if len(arg) < 1:
        power = np.mean(energy)
    else:
        power = np.mean(energy, axis=arg[0])
    return power


def signal_power_tf(signal_input, *arg):
    """
    Calculate the power of the input signal, default axis=0
    :param signal_input:
    :param arg:
                arg[0]: axis
    :return: power
    """
    energy = tf.pow(tf.abs(signal_input), 2)
    if len(arg) < 1:
        power = tf.reduce_sum(tf.reduce_mean(energy))
    else:
        power = tf.reduce_sum(tf.reduce_mean(energy, axis=arg[0]))
    return power


def array_response_uspa(phi, theta, N):
    """
    array response vector for the uniform square planar array (USPA) {len * len}
    :param phi: azimuth angle
    :param theta: elevation angle
    :param N: number of antennas
    :return:
    """
    y = np.zeros((N, 1), dtype=complex)
    len = int(np.sqrt(N))
    for m in range(len):
        for n in range(len):
            y[m*len+n] = np.exp(1j*np.pi*(m*np.sin(phi)*np.sin(theta) + n*np.cos(theta)))
    y = y / np.sqrt(N)
    y = np.ravel(y)       # Convent to 1-dimention, MAY BE NOT THE BEST WAY
    return y


def array_response_upa(phi, theta, N, rows, columns):
    """
    array response vector for the uniform square planar array (UPA) {row * column}
    :param phi: azimuth angle
    :param theta: elevation angle
    :param N: number of antennas
    :param rows: rows of antennas array
    :param columns: columns of antennas array
    :return:
    """
    # check the input
    if rows * columns != N:
        print("error!")

    y = np.zeros((N, 1), dtype=complex)
    for row in range(rows):
        for column in range(columns):
            y[row*columns+column] = np.exp(1j*np.pi*(row*np.sin(phi)*np.sin(theta) + column*np.cos(theta)))
    y = y / np.sqrt(N)
    y = np.ravel(y)       # Convent to 1-dimention, MAY BE NOT THE BEST WAY
    return y


def array_response_ula(phi, N):
    """
    array response vector for the uniform linear array (ULA)
    :param phi: azimuth angle
    :param N: number of antennas
    :return:
    """
    y = []
    for index in range(N):
        temp = np.exp(1j*np.pi*index*np.sin(phi))
        y.append(temp)
    y = y / np.sqrt(N)
    y = np.ravel(y)
    return y


def channel_generator(Nt, Nr, antenna_array, Nc=None, Nray=None):
    """
    This function is used to create Channel Model for mmWave base on extended Saleh-Valenzuela model,
    which allows us to accurately capture the mathematical structure present in mmWave channels.
    :param Nt: number of transmit antennas
    :param Nr: number of receive antennas
    :param Nc: number of cluster
    :param Nray: number of rays in each cluster
    :param antenna_array: antenna array (ULA, UPA, USPA)
    :return: H : channel matrix (Nt * Nr)
    """
    # defult
    if Nc == None:
        Nc = min(Nt, Nr)                        # 默认为满秩矩阵
    if Nray == None:
        Nray = 5                                # 默认为5
    angle_sigma = 10 / 180 * np.pi              # standard deviation of the angles in azimuth and elevation both of Rx and
    gamma = np.sqrt((Nt * Nr) / (Nc * Nray))    #
    sigma = 1                                   # according to the normalization condition of H

    H = np.zeros((Nr, Nt), dtype=complex)
    alpha = np.zeros((Nc * Nray), dtype=complex)
    At = np.zeros((Nt, Nc * Nray), dtype=complex)
    Ar = np.zeros((Nr, Nc * Nray), dtype=complex)
    AoD = np.zeros((2, Nc * Nray), dtype=complex)
    AoA = np.zeros((2, Nc * Nray), dtype=complex)
    for i in range(Nc):
        AoD_azi_m = np.random.uniform(0, 2 * np.pi, 1)  # Mean Angle of Departure _ azimuth
        AoD_ele_m = np.random.uniform(0, np.pi, 1)      # Mean Angle of Departure _ elevation
        AoA_azi_m = np.random.uniform(0, 2 * np.pi, 1)  # Mean Angle of Arrival_ azimuth
        AoA_ele_m = np.random.uniform(0, np.pi, 1)      # Mean Angle of Arrival_ elevation
        AoD[0, i * Nray:Nray * (i + 1)] = np.random.laplace(AoD_azi_m, angle_sigma, (1, Nray))
        AoD[1, i * Nray:Nray * (i + 1)] = np.random.laplace(AoD_ele_m, angle_sigma, (1, Nray))
        AoA[0, i * Nray:Nray * (i + 1)] = np.random.laplace(AoA_azi_m, angle_sigma, (1, Nray))
        AoA[1, i * Nray:Nray * (i + 1)] = np.random.laplace(AoA_ele_m, angle_sigma, (1, Nray))
    for j in range(Nc * Nray):
        if antenna_array == "ULA":
            At[:, j] = array_response_ula(AoD[0, j], Nt)              # ULA array response
            Ar[:, j] = array_response_ula(AoA[0, j], Nr)
        elif antenna_array == "UPA":
            At[:, j] = array_response_upa(AoD[0, j], AoD[1, j], Nt)   # UPA array response
            Ar[:, j] = array_response_upa(AoA[0, j], AoA[1, j], Nr)
        elif antenna_array == "USPA":
            At[:, j] = array_response_uspa(AoD[0, j], AoD[1, j], Nt)  # USPA array response
            Ar[:, j] = array_response_uspa(AoA[0, j], AoA[1, j], Nr)
        else:
            print("error!")

        alpha[j] = np.random.normal(0, np.sqrt(sigma / 2)) + 1j * np.random.normal(0, np.sqrt(sigma / 2))  # related to power normalization
        H = H + alpha[j] * Ar[:, [j]] * np.conj(np.transpose(At[:, [j]]))
    H = gamma * H
    H = np.transpose(np.conj(H))  # H --> H^H

    return H


class signal:
    """"""
    def __init__(self, mode=None, norm=None, Ns=None):
        mode = mode.upper()
        self.norm = norm
        self.Ns = Ns
        self.BPSK = {"dictionary": {'1': 1 + 0j, '0': -1 + 0j},
                     "scatter": [1, -1]
                     }
        self.QPSK_A = {"dictionary": {'11': 1 + 0j, '10': 0 + 1j, '01': -1 + 0j, '00': 0 - 1j},
                       "scatter": [1 + 0j, 0 + 1j, -1 + 0j, 0 - 1j]
                       }
        self.QPSK_B = {"dictionary": {'11': 1 + 1j, '10': 1 - 1j, '01': -1 + 1j, '00': -1 - 1j},
                       "scatter": [1 + 1j, 1 - 1j, -1 + 1j, -1 - 1j]
                       }
        self.PSK_8 = {"dictionary": {'000': np.exp(1j * np.pi * 0),     '001': np.exp(1j * np.pi * 1 / 4), '011': np.exp(1j * np.pi * 2 / 4), '010': np.exp(1j * np.pi * 3 / 4),
                                     '110': np.exp(1j * np.pi * 4 / 4), '111': np.exp(1j * np.pi * 5 / 4), '101': np.exp(1j * np.pi * 6 / 4), '100': np.exp(1j * np.pi * 7 / 4)},
                      "scatter": [np.exp(1j * np.pi * 0),     np.exp(1j * np.pi * 1 / 4), np.exp(1j * np.pi * 2 / 4), np.exp(1j * np.pi * 3 / 4),
                                  np.exp(1j * np.pi * 4 / 4), np.exp(1j * np.pi * 5 / 4), np.exp(1j * np.pi * 6 / 4), np.exp(1j * np.pi * 7 / 4)]
                      }
        self.QAM_16 = {"dictionary": {'1000': -3 + 3j, '1001': -1 + 3j, '1011': 1 + 3j, '1010': 3 + 3j,
                                      '1100': -3 + 1j, '1101': -1 + 1j, '1111': 1 + 1j, '1110': 3 + 1j,
                                      '0100': -3 - 1j, '0101': -1 - 1j, '0111': 1 - 1j, '0110': 3 - 1j,
                                      '0000': -3 - 3j, '0001': -1 - 3j, '0011': 1 - 3j, '0010': 3 - 3j},
                       "scatter": [-3 + 3j, -1 + 3j, 1 + 3j, 3 + 3j,
                                   -3 + 1j, -1 + 1j, 1 + 1j, 3 + 1j,
                                   -3 - 1j, -1 - 1j, 1 - 1j, 3 - 1j,
                                   -3 - 3j, -1 - 3j, 1 - 3j, 3 - 3j]
                       }
        self.PSK_16 = {"dictionary": {'0000': np.exp(1j * np.pi * 0),      '0001': np.exp(1j * np.pi * 1 / 8),  '0011': np.exp(1j * np.pi * 2 / 8),  '0010': np.exp(1j * np.pi * 3 / 8),
                                      '0110': np.exp(1j * np.pi * 4 / 8),  '0111': np.exp(1j * np.pi * 5 / 8),  '0101': np.exp(1j * np.pi * 6 / 8),  '0100': np.exp(1j * np.pi * 7 / 8),
                                      '1100': np.exp(1j * np.pi * 8 / 8),  '1101': np.exp(1j * np.pi * 9 / 8),  '1111': np.exp(1j * np.pi * 10 / 8), '1110': np.exp(1j * np.pi * 11 / 8),
                                      '1010': np.exp(1j * np.pi * 12 / 8), '1011': np.exp(1j * np.pi * 13 / 8), '1001': np.exp(1j * np.pi * 14 / 8), '1000': np.exp(1j * np.pi * 15 / 8), },
                       "scatter": [np.exp(1j * np.pi * 0),      np.exp(1j * np.pi * 1 / 8),  np.exp(1j * np.pi * 2 / 8),  np.exp(1j * np.pi * 3 / 8),
                                   np.exp(1j * np.pi * 4 / 8),  np.exp(1j * np.pi * 5 / 8),  np.exp(1j * np.pi * 6 / 8),  np.exp(1j * np.pi * 7 / 8),
                                   np.exp(1j * np.pi * 8 / 8),  np.exp(1j * np.pi * 9 / 8),  np.exp(1j * np.pi * 10 / 8), np.exp(1j * np.pi * 11 / 8),
                                   np.exp(1j * np.pi * 12 / 8), np.exp(1j * np.pi * 13 / 8), np.exp(1j * np.pi * 14 / 8), np.exp(1j * np.pi * 15 / 8)]
                       }

        # 初始化时，将当前调制模式设为传入参数 mode
        if mode == "BPSK" or mode == "2PSK"or mode == "2_PSK" or mode == "PSK_2":
            self.mode = self.BPSK
        elif mode == "QPSK_A":
            self.mode = self.QPSK_A
        elif mode == "QPSK_B" or mode == "QPSK"or mode == "4QAM"or mode == "QAM" or mode == "QAM_4"or mode == "4_QAM":
            self.mode = self.QPSK_B
        elif mode == "PSK_8" or mode == "8PSK" or mode == "8_PSK"or mode == "PSK8":
            self.mode = self.PSK_8
        elif mode == "PSK_16" or mode == "16_PSK" or mode == "PSK16" or mode == "16PSK":
            self.mode = self.PSK_16
        elif mode == "QAM_16" or mode == "16_QAM" or mode == "16QAM" or mode == "QAM16":
            self.mode = self.QAM_16
        else:
            raise IOError("Check input modulation mode(检查输入的调制模式是否正确)")

        # 根据选择的调制方式计算参数
        self.bit = int(np.log2(len(self.mode["scatter"])))  # b = log2(s) 每个符号的比特数

        # 根据传入参数 norm 计算放缩比例
        if self.norm == "power_normalization_to_1":
            self.scatter_power = np.sqrt(self.signal_power(self.mode["scatter"]))
        elif self.norm == "power_normalization_to_1/Ns":
            self.scatter_power = np.sqrt(self.signal_power(self.mode["scatter"]) * self.Ns)
        else:
            raise IOError("Check input normalization mode(检查输入的归一化模式是否正确)")

    @staticmethod
    def signal_power(signal_input, *arg):
        """
        Calculate the power of the input signal, default axis=0
        :param signal_input:
        :param arg:
                    arg[0]: axis
        :return: power
        """
        signal_T = np.array(signal_input)
        energy = np.abs(signal_T) ** 2
        if len(arg) < 1:
            power = np.mean(energy)
        else:
            power = np.mean(energy, axis=arg[0])
        return power

    @staticmethod
    def signal_power_tf(signal_input, *arg):
        """
        Calculate the power of the input signal, default axis=0
        :param signal_input:
        :param arg:
                    arg[0]: axis
        :return: power
        """
        energy = tf.pow(tf.abs(signal_input), 2)
        if len(arg) < 1:
            power = tf.reduce_sum(tf.reduce_mean(energy))
        else:
            power = tf.reduce_sum(tf.reduce_mean(energy, axis=arg[0]))
        return power

    @staticmethod
    def db2power(db):
        """
        dB value to power
        :param db: dB value
        :return: power
        """
        power = np.power(10, db / 10)
        return power

    @staticmethod
    def power2db(power):
        """
         power to dB value
        :param power: power value
        :return: db: dB value
        """
        db = 10 * np.log10(power)
        return db

    @staticmethod
    def binary2str(data):
        """
        binary sequence  [0, 1, ..., 0] --to--> str "01...0"
        :return: str of binary sequence
        """
        bits = len(data)
        data = np.reshape(data, [-1, 1])  # 确保数据的维度只有一维
        data_str = str(data[0][0])
        for i in range(1, bits, 1):
            data_str = data_str + str(data[i][0])
        return data_str

    @staticmethod
    def count_accuracy_rate(binary_1, binary_2):
        """
        calculation the accuracy rate (bit error rate)
        :param binary_1:
        :param binary_2:
        :return: accuracy rate
        """
        binary_1 = np.array(binary_1)
        binary_2 = np.array(binary_2)
        error_num = np.sum(np.abs(binary_1 - binary_2))
        T = np.size(binary_1)
        bit_error_rate = error_num / int(np.size(binary_1))
        accuracy = 1. - bit_error_rate
        return accuracy

    @staticmethod
    def get_key(dictionary, value):
        """
        从字典dictionary中找到value对应的key值
        :param dictionary: 目的字典
        :param value: 查找的value
        :return: value对应的key
        """
        return [k for k, v in dictionary.items() if v == value]

    def noise_generator(self, power=None, SNR=None, size=None):
        """generate db dB noise with shape = shape , default signal power = 1
        """
        alpha = self.db2power(SNR)
        sigma = np.sqrt(power / alpha)  # 计算噪声标准差
        # 产生噪声
        noise_data = np.sqrt(0.5) * (np.random.normal(0, sigma, size=size) + np.random.normal(0, sigma, size=size) * 1j)
        noise_data = noise_data.astype(np.complex64)
        return noise_data

    def signal_generator(self, size=None):
        """
        "产生调制模式为 mode , 形状为 size 的复信号"
        :param size: size of output
        :return: binary_data, complex_signal_reshape, complex_signal_std
        """
        n = reduce(lambda x, y: x*y, size)  # 复信号信号长度
        binary_data = np.random.randint(2, size=(n, self.bit))  # 产生二进制序列 shape(n, b)
        binary_data_reshape = np.reshape(binary_data, [1, -1], order="C")
        complex_signal_std = []
        complex_signal_normalization = []
        for i in range(n):
            data_str = self.binary2str(binary_data[i])
            complex_signal = self.mode["dictionary"].get(data_str)
            complex_signal_std.append(complex_signal)
            complex_signal_normalization.append(complex_signal / self.scatter_power)
        complex_signal_reshape = np.reshape(complex_signal_normalization, size).astype(np.complex64)
        complex_signal_std = np.array(complex_signal_std).astype(np.complex64)
        scatter_std = self.mode["scatter"] / self.scatter_power
        return binary_data_reshape, complex_signal_reshape, complex_signal_std, scatter_std

    def signal_decoder(self, signal_receive):
        """
        dMap the input signal to the scatter diagram and demodulate the binary data --to--> [binary_data, complex_data]
        :param signal_receive: receive data
        :return: binary_data, complex_data_norm, complex_data_std
        """
        size = np.shape(signal_receive)
        signal_receive1 = np.array(signal_receive).reshape([-1, 1])
        # 进行星座映射前，将信号放缩回标准的幅度、
        signal_norm = signal_receive1 * self.scatter_power
        n = len(signal_receive1)  # 接收复信号信号长度
        binary_data = []
        complex_data_std = []
        for i in range(n):
            data_temp = signal_norm[i, :]
            distance = np.abs(data_temp - self.mode["scatter"])
            distance_min = np.min(distance)
            where = np.where(distance == distance_min)[0]
            index = int(where[0])
            result = self.mode["scatter"][index]
            complex_data_std.append(result)
            code = self.get_key(self.mode["dictionary"], result)
            for j in range(self.bit):
                binary_data.append(int(code[0][j]))
        complex_data = complex_data_std / self.scatter_power
        binary_data = np.reshape(binary_data, [1, -1])
        complex_data = np.reshape(complex_data, size).astype(np.complex64)
        complex_data_std = np.array(complex_data_std).astype(np.complex64)
        return binary_data, complex_data, complex_data_std
        pass

    @staticmethod
    def linear_interpolation(h1, h2, n_inter):
        """
        Linear interpolation between h1 and h2
        :param h1: Channel matrix_1
        :param h2: Channel matrix_2
        :param n_inter: Interpolation number n_inter = n + 2
        :return: [h_1=h1, h_2, ..., h_n_inter=h2] array
        """
        h1 = np.array(h1)
        h2 = np.array(h2)
        n = n_inter - 1
        delta_h = (h2 - h1) / n
        h_sequence = [h1]
        # 初始化
        h = h1
        for i in range(1, n_inter):
            h = h + delta_h
            h_sequence.append(h)
        h_sequence = np.array(h_sequence)
        return h_sequence

    def traversal_scatter(self):
        """
        traversal scatter
        :return: complex signal
        """
        scatter_signal = np.array(self.mode["scatter"])
        temp_signal = []
        if self.Ns == 1:
            temp_signal = scatter_signal
        if self.Ns == 2:
            for i in scatter_signal:
                for j in scatter_signal:
                    temp_signal.append([i, j])
        if self.Ns == 4:
            for i in scatter_signal:
                for j in scatter_signal:
                    for k in scatter_signal:
                        for l in scatter_signal:
                            temp_signal.append([i, j, k, l])
        complex_signal = np.array(temp_signal)/self.scatter_power

        return complex_signal

    def get_ber(self, x, h, noise, *args):
        """
        get ber
        :param x: input signal
        :param h: channel matrix
        :param noise: noise
        :param args: beamforming matrix
        :return:
        """
        data_dict = {}
        data_dict["x"] = x
        data_dict["h"] = h
        data_dict["noise"] = noise
        # fully digital beamforming
        if len(args) == 2:
            pc_output = np.dot(x, args[0])
            h_output = np.dot(pc_output, h)
            noise_output = h_output + noise
            r_bb_output = np.dot(noise_output, args[1])
            data_dict["pc_output"] = pc_output
            data_dict["t_bb_output"] = pc_output
            data_dict["h_output"] = h_output
            data_dict["noise_output"] = noise_output
            data_dict["r_bb_output"] = r_bb_output
        # hybrid beamforming
        if len(args) == 4:
            t_bb_output = np.dot(x, args[0])
            pc_output = np.dot(t_bb_output, args[1])
            h_output = np.dot(pc_output, h)
            noise_output = h_output + noise
            r_rf_output = np.dot(noise_output, args[2])
            r_bb_output = np.dot(noise_output, args[3])
            data_dict["t_bb_output"] = t_bb_output
            data_dict["t_rf_output"] = pc_output
            data_dict["pc_output"] = pc_output
            data_dict["h_output"] = h_output
            data_dict["noise_output"] = noise_output
            data_dict["r_rf_output"] = r_rf_output
            data_dict["r_bb_output"] = r_bb_output
        # decoder
        binary_real, _, _ = self.signal_decoder(x)
        binary_pred, _, _ = self.signal_decoder(r_bb_output)
        ber = 1 - self.count_accuracy_rate(binary_pred, binary_real)
        data_dict["ber"] = ber

        return data_dict


# sig = signal("QPSK", "power_normalization_to_1", 4)
# x = np.array(list(sig.traversal_scatter()))
# p = np.sum(sig.signal_power(x, 0))
# print(x)
# pass

