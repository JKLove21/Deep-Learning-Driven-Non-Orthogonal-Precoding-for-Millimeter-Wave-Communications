import tensorflow as tf
import lib.config.config_1BSNt_KUENr as cfg
import lib.utils.communication_tools as ct
import lib.network.network_quantization as net
import lib.utils.SaveAndLoad as sal
import scipy.io as sio
import numpy as np


def q_train(model, saver, sess, data_generator, resume_itr, channel, quant_mode, angle):
    # parameters for interval
    SAVE_INTERVAL = 1000
    SUMMARY_INTERVAL = 1000
    PRINT_INTERVAL = 100

    if cfg.FLAGS.log:
        train_writer = tf.summary.FileWriter(cfg.FLAGS.logdir, sess.graph)  # 生成计算图

    # plt.figure(1)
    # plt.ion()
    num_training = cfg.FLAGS.num_q_training
    plot_list = []
    acc_print = []
    loss_print = []
    itr_print = []
    snr_train = cfg.FLAGS.snr_training
    for itr in range(resume_itr, num_training):

        # 变学习率

        lr = 0.001

        # 变信噪比
        # if itr > 0.50 * num_training:
        #     snr_train = -3
        #
        # if itr > 0.60 * num_training:
        #     snr_train = 0
        #
        # if itr > 0.70 * num_training:
        #     snr_train = -5

        # random noise
        # snr_train = np.random.uniform(-15, 15, 1)
        _, batch_x, _, scatter_std = data_generator.signal_generator([cfg.FLAGS.batch_size, model.Ns])
        batch_noise = data_generator.noise_generator(1, snr_train, [cfg.FLAGS.batch_size, model.Nr])
        batch_h = channel

        feed_dict = {model.real_x: np.float32(np.real(batch_x)),
                     model.imag_x: np.float32(np.imag(batch_x)),
                     model.real_h: np.float32(np.real(batch_h)),
                     model.imag_h: np.float32(np.imag(batch_h)),
                     model.real_noise: np.float32(np.real(batch_noise)),
                     model.imag_noise: np.float32(np.imag(batch_noise)),
                     model.lr: lr,
                     # model.parameters_q: quant_parameter
                     }
        # input tensors
        input_tensors = [model.train_op, model.lr]
        if (itr % SUMMARY_INTERVAL == 0) or (itr % PRINT_INTERVAL == 0):
            input_tensors.extend([model.summary_op, model.predictions, model.pre, model.x, model.loss])
        # sess run
        result = sess.run(input_tensors, feed_dict)
        # print
        if (itr != 0) and itr % PRINT_INTERVAL == 0:
            binary_real, _, _ = data_generator.signal_decoder(result[-2])
            binary_pred, _, _ = data_generator.signal_decoder(result[-3])
            acc = data_generator.count_accuracy_rate(binary_pred, binary_real)
            print_str = "Iteration: " + str(itr)
            print_str += " lr: " + str(result[1])
            print_str += " SNR: " + str(snr_train)
            print_str += " Loss: " + str(result[-1])
            print_str += " Acc: " + str(acc)
            print(print_str)

        # print(result[-4]["theta_t"])
        # print(result[-4]["theta_r"])
        # print(result[-4]["theta_t1"])
        # print(result[-4]["theta_r1"])
        # acc_print.append(acc)
        # loss_print.append(result[-1])


        # save result
        # temp = {}
        # temp["predictions"] = result[-4]
        # temp["itr"] = itr
        # temp["loss"] = result[-1]
        # temp["acc"] = acc
        # plot_list.append(temp)
        # plt.cla()
        # #
        # plt.scatter(np.real(result[-3]), np.imag(result[-3]), s=10)
        # plt.scatter(np.real(scatter_std), np.imag(scatter_std), s=30)
        # plt.xlabel("Real")
        # plt.ylabel("Imag")
        # # plt.title("scatter figure of x after " + str(itr) + " trains,\nBER = " + str(1 - acc) + "\nSNR = " + str(snr_train) + "dB")
        # plt.pause(0.001)
        # save
        if (itr != 0) and itr % SAVE_INTERVAL == 0:
            print("saving model...")
            saver.save(sess, quant_mode + "/" + cfg.FLAGS.logdir + '/model' + str(itr))
        # summary
        if itr % SUMMARY_INTERVAL == 0:
            if cfg.FLAGS.log:
                train_writer.add_summary(result[-5], itr)
    # plt.ioff()
    # plt.show()
    # sio.savemat('phase_ternary_acc_concat.mat', {'phase_ternary_acc_concat': acc_print})
    # sio.savemat('phase_ternary_loss_concat.mat', {'phase_ternary_loss_concat': loss_print})
    # print("保存完成")
    saver.save(sess, quant_mode + "/" + cfg.FLAGS.logdir + '/model' + str(itr))
    sal.save_pkl(cfg.FLAGS.path_for_results, plot_list)


def q_test(model, sess, data_generator, channel, quant_mode):
    print(quant_mode + " testing。。。")
    n_frames = int(cfg.FLAGS.N_bits_test/data_generator.bit/cfg.FLAGS.Ns)
    BER = {}
    x = []
    y = []
    for snr in range(-10, 10, 1):
        _, batch_x, _, scatter_std = data_generator.signal_generator([n_frames, model.Ns])
        batch_noise = data_generator.noise_generator(1, snr, [n_frames, model.Nr])
        batch_h = channel

        feed_dict = {model.real_x: np.float32(np.real(batch_x)),
                     model.imag_x: np.float32(np.imag(batch_x)),
                     model.real_h: np.float32(np.real(batch_h)),
                     model.imag_h: np.float32(np.imag(batch_h)),
                     model.real_noise: np.float32(np.real(batch_noise)),
                     model.imag_noise: np.float32(np.imag(batch_noise))
                     }
        input_tensors = [model.pre, model.x]
        result = sess.run(input_tensors, feed_dict)
        binary_real, _, _ = data_generator.signal_decoder(result[0])
        binary_pred, _, _ = data_generator.signal_decoder(result[1])
        acc = data_generator.count_accuracy_rate(binary_pred, binary_real)
        x.append(snr)
        y.append(1-acc)
        print("SNR = " + str(snr) + " ,BER = " + str(1-acc))
    BER["x"] = x
    BER["y"] = y
    sal.save_pkl(quant_mode + "/" + cfg.FLAGS.path_for_ber_quant, BER)


# def RF_quantization(model, sess, data_generator, channel, angle):

    # print("Quant_part " + str(angle*2))
    # quantization = qut.Quantization(angle*2)
    # print("load parameters...")
    # parameters = sess.run(model.parameters)
    # print("quantization...")
    # theta_t = quantization.quantificat(parameters["theta_t"])
    # theta_r = quantization.quantificat(parameters["theta_r"])
    # parameters_q = parameters
    # parameters_q["theta_t"] = np.float32(theta_t)
    # parameters_q["theta_r"] = np.float32(theta_r)

    # close graph....
    # print("close graph...")
    # tf.reset_default_graph()
    # print("rebuilt model...")
    # model = net.Cdnn_quant(angle)
    # model.summary_op = tf.summary.merge_all()
    # saver = tf.train.Saver(tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES), max_to_keep=1)
    # sess = tf.InteractiveSession()
    # resume_itr = 0
    # tf.global_variables_initializer().run()
    # tf.train.start_queue_runners()
    # if cfg.FLAGS.quant_mode == "quantization":
    #     print("quantization...")
    #     q_test(model, sess, data_generator, channel, cfg.FLAGS.quant_mode +"/"+cfg.FLAGS.angle)
    # else:
    #     if cfg.FLAGS.quantization_training:
    #         print(cfg.FLAGS.quant_mode + "retrain....")
    #         q_train(model, saver, sess, data_generator, resume_itr, channel, cfg.FLAGS.quant_mode + "/"+cfg.FLAGS.angle, angle)
    #         print("retrain...")
    #         q_test(model, sess, data_generator, channel, cfg.FLAGS.quant_mode +"/"+ cfg.FLAGS.angle)


def main(channel, angle):
    # make dir
    sal.mkdir(cfg.FLAGS.path)
    # built model
    model = net.Cdnn_quant(angle)
    print_str = "K=" + str(model.K)
    print_str += ", Ns=" + str(model.Ns)
    print_str += ", Ntrf=" + str(model.Ntrf)
    print_str += ", Nt=" + str(model.Nt)
    print_str += ", Nr=" + str(model.Nr)
    print_str += ", Nrrf=" + str(model.Nrrf)
    print(print_str)

    model.summary_op = tf.summary.merge_all()
    saver = tf.train.Saver(tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES), max_to_keep=1)
    sess = tf.InteractiveSession()

    resume_itr = 0

    tf.global_variables_initializer().run()
    tf.train.start_queue_runners()

    data_generator = ct.signal(cfg.FLAGS.modulation_mode, cfg.FLAGS.power_normalization, model.Ns)
    if cfg.FLAGS.resume or not cfg.FLAGS.train:
        model_file = tf.train.latest_checkpoint(cfg.FLAGS.logdir + "")
        if model_file:
            ind1 = model_file.index('model')
            resume_itr = int(model_file[ind1+5:])
            print("Restoring model weights from " + model_file)
            saver.restore(sess, model_file)
    # if cfg.FLAGS.quantization:
    #     RF_quantization(model, sess, data_generator, channel, angle)
    if cfg.FLAGS.quant_mode == "quantization":
        print("quantization...")
        q_test(model, sess, data_generator, channel, cfg.FLAGS.quant_mode +"/"+cfg.FLAGS.angle)
    else:
        if cfg.FLAGS.quantization_training:
            print(cfg.FLAGS.quant_mode + "retrain....")
            q_train(model, saver, sess, data_generator, resume_itr, channel, cfg.FLAGS.quant_mode + "/"+cfg.FLAGS.angle, angle)
        if cfg.FLAGS.quantization_test:
            print("retrain...")
            q_test(model, sess, data_generator, channel, cfg.FLAGS.quant_mode +"/"+ cfg.FLAGS.angle)


if __name__ == "__main__":
    modulation_dict = [
        "QAM",
        # "16QAM"
    ]
    channel_dict = [
        # "mimochannel_more",
        # "mimochannel_equal",
        "mimochannel_less"
    ]
    quantization_dict = [
        "original",
        # "quantization",
        # "quantization + retrain"
    ]
    angle_list = [
         15000,
        # 4,
        # 6,
        # 12,
    ]
    h_list = [
        "H0.5",
        # "H0.9",
        # "H0.8",
        # "H0.7",
        # "H0.6",
        # "H0.5",
        # "H0.4",
        # "H0.3",
        # "H0.2",
        # "H0.1",
    ]

    for i, h_name in enumerate(h_list):
        for a, angle in enumerate(angle_list):
            cfg.FLAGS.angle = "/pi_" + str(angle)
            mimochannel = sio.loadmat("C:/Users/supreme ljk/Desktop/HB_Final/H_mat_quantization/pi_" + str(angle)+h_name + ".mat")
            for m, modulation_mode in enumerate(modulation_dict):
                for n, channel_name in enumerate(channel_dict):
                    for k, quant_mode in enumerate(quantization_dict):
                        path = "data_quant/" + modulation_mode + "/" + channel_name
                        # change path
                        cfg.FLAGS.quant_mode = quant_mode
                        cfg.FLAGS.modulation_mode = modulation_mode
                        cfg.FLAGS.path = path   # data_quant/QAM/
                        cfg.FLAGS.logdir = path + "/logdir"
                        cfg.FLAGS.path_for_hsets_quant = path + "/hsets.pkl"
                        cfg.FLAGS.path_for_results = path + "/" + h_name + "results.pkl"
                        cfg.FLAGS.path_for_ber_quant = path + "/"+h_name + "ber.pkl"
                        # cfg.FLAGS.path_for_ber = path + "/pi_" + str(angle)+h_name + "ber.pkl"
                        sal.mkdir(quant_mode + "/pi_" + str(angle) + "/" + path)  # 创建路径
                        H = mimochannel["H"]
                        print(h_name)
                        main(H, angle)
                        tf.reset_default_graph()
                        print("reset default graph...")