import os
from tensorflow.python import pywrap_tensorflow
import scipy.io as sio

model_dir = ""
checkpoint_path = os.path.join(model_dir, "data/HB/partially/logdir\\model4950")
# Read data from checkpoint file
reader = pywrap_tensorflow.NewCheckpointReader(checkpoint_path)
var_to_shape_map = reader.get_variable_to_shape_map()
# Print tensor name and values
for key in var_to_shape_map:
    # if key == 'theta_r' or 'theta_t':
    print("tensor_name: ", key)
    print(reader.get_tensor(key))
    m = key
    N = m.replace("/", "")
    print(N)
    sio.savemat(N, {str(N): reader.get_tensor(key)})

# C:/Users/supreme ljk/Desktop/HB_Final/original/pi_8/data_quant/QAM/mimochannel_less/logdir\\model999
# C:/Users/supreme ljk/Desktop/HB_Final/data/HB/fully/logdir\\model9600

