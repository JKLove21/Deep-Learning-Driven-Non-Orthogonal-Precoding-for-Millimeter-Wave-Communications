import tensorflow as tf
import lib.config.config_1BSNt_KUENr as cfg
import communication_tools_taojiyun as cttjy
# import lib.network.network_fully_digital_beamforming as net
import lib.network.network_1BSNt_KUENr as net
import lib.utils.SaveAndLoad as sal
import matplotlib.pyplot as plt
import numpy as np
import os
import scipy.io as sio
from tensorflow.python import pywrap_tensorflow

PRINT_INTERVAL = 100
interval = 100


def train(model, saver, sess, data_generator, resume_itr):

    SUMMARY_INTERVAL = 100
    PRINT_INTERVAL = 50

    if cfg.FLAGS.log:
        train_writer = tf.summary.FileWriter(cfg.FLAGS.logdir, sess.graph)  # 生成计算图
    print('Done initializing, starting training.')

    # if os.access(cfg.FLAGS.path_for_hsets, os.F_OK) and cfg.FLAGS.h_select:
    #     hsets = sal.load_pkl(cfg.FLAGS.path_for_hsets)
    #     print("用的是第一路径")
    # else:
    h = {}

    # h["mimochan0"] = ct.channel_generator(model.Nt, model.Nr_total, "ULA", 2, 5)
    # h["mimochan0"] = np.random.randn(model.Nt, model.Nr) + 1j * np.random.randn(model.Nt, model.Nr)
    # h["mimochan0"] = sio.loadmat("C:/Users/supreme ljk/Desktop/HB_Final/H_mat/FastBeamforming_2.mat")["data"][0, 0]["C1R4N1"][0, 0]["H"]   # 64 × 16 的维度
    h["mimochan0"] = sio.loadmat("C:/Users/supreme ljk/Desktop/HB_Final/H_mat/H_C5R10_TEST3.mat")["H"]  # 64 × 64 的维度
    # h["mimochan0"] = sio.loadmat("C:/Users/supreme ljk/Desktop/HB_Final/H_mat/H_C6R1_MU_4.mat")["H"]  # 64 × 64 的维度
    # h["mimochan0"] = sio.loadmat("C:/Users/supreme ljk/Desktop/HB_Final/H_mat_quantization/pi_3H0.5.mat")["H"]  # 64 × 16 的维度
    hsets = h
    print("saving h sets...")

    sal.save_pkl(cfg.FLAGS.path_for_hsets, h)

    save_flag = 1
    best_loss = 1000
    # snr_train = np.round(np.random.uniform(-10, 10, 1))
    snr_train = cfg.FLAGS.snr_training

    # iteration = []
    # loss_print = []
    # acc_print = []
    # lr_list = []
    # lr_list_temp = np.zeros([22, cfg.FLAGS.num_training])
    # for j in range(interval):
    #     lr_list.append((j + 1) * 0.1 / interval)
    # print(str("学习率") + str(lr_list[i]))
    # for itr in range(resume_itr, cfg.FLAGS.num_training):
    #
    #     baseband = {}
    #     baseband_temp = {}
    #     rf_beamforming = {}
    #     rf_beamforming_temp = {}
    #     combine = {}
    #     combine_temp = {}
    #     rf_combine = {}
    #     rf_combine_temp = {}
    #     distance_list = []
    #
    #     _, batch_x, _, _ = data_generator.signal_generator([cfg.FLAGS.batch_size, model.Ns_total])
    #     batch_noise = data_generator.noise_generator(1, snr_train, [cfg.FLAGS.batch_size, model.Nr_total])
    #     batch_h = hsets["mimochan0"]
    #
    #     lr = lr_list[i]
    #
    #     feed_dict = {model.real_x: np.float32(np.real(batch_x)),
    #                  model.imag_x: np.float32(np.imag(batch_x)),
    #                  model.real_h: np.float32(np.real(batch_h)),
    #                  model.imag_h: np.float32(np.imag(batch_h)),
    #                  model.real_noise: np.float32(np.real(batch_noise)),
    #                  model.imag_noise: np.float32(np.imag(batch_noise)),
    #                  model.lr: lr
    #                  }
    #
    #     input_tensors = [model.train_op]
    #     input_tensors.extend([model.summary_op, model.predictions, model.pre, model.x, model.loss])
    #     result = sess.run(input_tensors, feed_dict)
    #
    #     loss = result[-1]
    #     loss_list[i, itr] = loss
    #     predictions = result[-4]
    #     binary_real, _, _ = data_generator.signal_decoder(result[-2])
    #     binary_pred, _, _ = data_generator.signal_decoder(result[-3])
    #     acc = data_generator.count_accuracy_rate(binary_pred[0], binary_real[0])
    #     if (itr % SUMMARY_INTERVAL == 0) or (itr % PRINT_INTERVAL == 0):
    #         print("Iteration:%6d/%-6d | training_SNR:%5f | loss:%8f | acc:%5f | lr:%5f" % (itr, cfg.FLAGS.num_training, snr_train, loss, acc, lr))
    #
    #     if save_flag == 1 and itr % PRINT_INTERVAL == 0:
    #         if loss < best_loss:
    #             best_loss = loss
    #             # print("saving model...")
    #
    #     if itr % SUMMARY_INTERVAL == 0:
    #         if cfg.FLAGS.log:
    #             train_writer.add_summary(result[1], itr)
    #             # saver.save(sess, cfg.FLAGS.logdir + '/model' + str(i) + str('_') + str(itr))
    #
    # if i == interval-1:
    #     sio.savemat("loss_beamforming", {"loss_beamforming": loss_list})

        # 比较欧式距离
        # baseband[str("baseband_beamforming_") + str(i)] = sio.loadmat(str("baseband_beamforming_") + str(i) + str(".mat"))["tensor"]
        # model_dir = ""
        # checkpoint_path = os.path.join(model_dir, "data/HB/fully/logdir\\model" + str(itr))
        # # Read data from checkpoint file
        # reader = pywrap_tensorflow.NewCheckpointReader(checkpoint_path)
        # var_to_shape_map = reader.get_variable_to_shape_map()
        # # Print tensor name and values
        # for key in var_to_shape_map:
        #     if key == "baseband_beamforming/Variable":
        #         baseband_temp["baseband_beamforming_0"] = reader.get_tensor(key)
        #     elif key == "baseband_beamforming/Variable_" + str(i):
        #         baseband_temp[str("baseband_beamforming_") + str(i)] = reader.get_tensor(key)
        # for j in range(INTERNAL):
        #     distance_list[j] = tf.abs(tf.subtract(baseband[str("baseband_beamforming_") + str(i)], lr_list[j] * baseband_temp[str("baseband_beamforming_") + str(i)]))
        #     index = tf.argmin(distance_list)
        #     temp.append(self.quadrant_list[index])

        # # 星座图
        # plt.cla()
        #
        # plt.scatter(np.real(predictions["r_bb_output"]), np.imag(predictions["r_bb_output"]), s=10)
        # # plt.scatter(np.real(datasets["scatter_std"]), np.imag(datasets["scatter_std"]), s=30)
        # plt.xlabel("Real")
        # plt.ylabel("Imag")
        # plt.title("scatter figure of x after " + str(itr) + " trains,\nBER = " + str(1 - acc) + "\nSNR = " + str(snr_train) + "dB")
        # plt.pause(0.1)



    # plt.ioff()
    # plt.show()
    # sio.savemat('Fast_itr_H2.mat', {'Fast_itr_H2': iteration})
    # sio.savemat('Fast_loss_H2', {'Fast_loss_H2': loss_print})
    # sio.savemat('Fast_acc_H2', {'Fast_acc_H2': acc_print})

    # if not cfg.FLAGS.pretrained_data_store:
    #     saver.save(sess, cfg.FLAGS.logdir + '\\model' + str(itr))
    # else:
    #     saver.save(sess, cfg.FLAGS.store_data_pre + '\\pretrained_model' + str(itr))

    iteration = []
    loss_print = []
    acc_print = []

    for itr in range(resume_itr, cfg.FLAGS.num_training):



        # 变学习率
        lr = cfg.FLAGS.lr

        # if itr < 0.030 * cfg.FLAGS.num_training:
        #     lr = 0.01  # 0.01 前300步
        # else:
        #     lr = cfg.FLAGS.lr
        #
        # if itr < 200:
        #     m = sio.loadmat("OLR.mat")
        #     n = m["lr"]
        #     lr = n[0, itr]
        #
        # elif itr > 200 or itr == 200:
        #     lr = 0.001


        # 变信噪比
        # if itr > 0.50*cfg.FLAGS.num_training:
        #     snr_train = -3
        #     save_flag = 0
        #
        # if itr > 0.60*cfg.FLAGS.num_training:
        #     snr_train = 0
        #     save_flag = 0
        #
        # if itr > 0.70*cfg.FLAGS.num_training:
        #     snr_train = -5
        #     save_flag = 1

        _, batch_x, _, _ = data_generator.signal_generator([cfg.FLAGS.batch_size, model.Ns_total])
        batch_noise = data_generator.noise_generator(1, snr_train, [cfg.FLAGS.batch_size, model.Nr_total])
        batch_h = hsets["mimochan0"]

        case = 0
        # 拿到对应mode调制方式下的batch的实部和虚部
        vec_real = np.abs(np.real(batch_x[:, 0]))
        vec_imag = np.abs(np.imag(batch_x[:, 0]))

        if case == 0:
            batch_x = batch_x
        elif case == 1:  # 1+1j,1+1j
            batch_x[:, 0] = vec_real + vec_imag * 1j
            batch_x[:, 1] = vec_real + vec_imag * 1j
        elif case == 2:  # 1+1j,-1+1j
            batch_x[:, 0] = vec_real + vec_imag * 1j
            batch_x[:, 1] = -vec_real + vec_imag * 1j
        elif case == 3:  # 1+1j,1-1j
            batch_x[:, 0] = vec_real + vec_imag * 1j
            batch_x[:, 1] = vec_real - vec_imag * 1j
        elif case == 4:  # 1+1j,-1-1j
            batch_x[:, 0] = vec_real + vec_imag * 1j
            batch_x[:, 1] = -vec_real - vec_imag * 1j

        elif case == 5:  # -1+1j,1+1j
            batch_x[:, 0] = -vec_real + vec_imag * 1j
            batch_x[:, 1] = vec_real + vec_imag * 1j
        elif case == 6:  # -1+1j,-1+1j
            batch_x[:, 0] = -vec_real + vec_imag * 1j
            batch_x[:, 1] = -vec_real + vec_imag * 1j
        elif case == 7:  # -1+1j,1-1j
            batch_x[:, 0] = -vec_real + vec_imag * 1j
            batch_x[:, 1] = vec_real - vec_imag * 1j
        elif case == 8:  # -1+1j,-1-1j
            batch_x[:, 0] = -vec_real + vec_imag * 1j
            batch_x[:, 1] = -vec_real - vec_imag * 1j
        elif case == 9:  # 1-1j,1+1j
            batch_x[:, 0] = vec_real - vec_imag * 1j
            batch_x[:, 1] = vec_real + vec_imag * 1j
        elif case == 10:  # 1-1j,-1+1j
            batch_x[:, 0] = vec_real - vec_imag * 1j
            batch_x[:, 1] = -vec_real + vec_imag * 1j
        elif case == 11:  # 1-1j,1-1j
            batch_x[:, 0] = vec_real - vec_imag * 1j
            batch_x[:, 1] = vec_real - vec_imag * 1j
        elif case == 12:  # 1-1j,-1-1j
            batch_x[:, 0] = vec_real - vec_imag * 1j
            batch_x[:, 1] = -vec_real - vec_imag * 1j

        elif case == 13:  # -1-1j,1+1j
            batch_x[:, 0] = -vec_real - vec_imag * 1j
            batch_x[:, 1] = vec_real + vec_imag * 1j
        elif case == 14:  # -1-1j,-1+1j
            batch_x[:, 0] = -vec_real - vec_imag * 1j
            batch_x[:, 1] = -vec_real + vec_imag * 1j
        elif case == 15:  # -1-1j,1-1j
            batch_x[:, 0] = -vec_real - vec_imag * 1j
            batch_x[:, 1] = vec_real - vec_imag * 1j
        elif case == 16:  # -1-1j,-1-1j
            batch_x[:, 0] = -vec_real - vec_imag * 1j
            batch_x[:, 1] = -vec_real - vec_imag * 1j

        # sio.savemat('batch_x', {'batch_x': batch_x})
        # batch_x = sio.loadmat('batch_x')['batch_x']

        feed_dict = {model.real_x: np.float32(np.real(batch_x)),
                     model.imag_x: np.float32(np.imag(batch_x)),
                     model.real_h: np.float32(np.real(batch_h)),
                     model.imag_h: np.float32(np.imag(batch_h)),
                     model.real_noise: np.float32(np.real(batch_noise)),
                     model.imag_noise: np.float32(np.imag(batch_noise)),
                     model.lr: lr,
                     }

        input_tensors = [model.train_op]

        # if (itr % SUMMARY_INTERVAL == 0) or (itr % PRINT_INTERVAL == 0):
        input_tensors.extend([model.summary_op, model.predictions, model.pre, model.x, model.loss])

        result = sess.run(input_tensors, feed_dict)

        # if itr % SUMMARY_INTERVAL == 0:
        #     t_bb_output_x.append(itr)
        #     t_bb_output_y.append(np.mean(np.power(abs(result[-4]["t_bb_output"]), 2), 0))

        # if (itr != 0) and itr % PRINT_INTERVAL == 0:
        loss = result[-1]
        predictions = result[-4]
        rank_predictions = result[-5]
        binary_real, _, _ = data_generator.signal_decoder(result[-2])
        binary_pred, _, _ = data_generator.signal_decoder(result[-3])
        acc = data_generator.count_accuracy_rate(binary_pred[0], binary_real[0])

        # power_x = np.sum(ct.signal_power(predictions["x"], 0))
        # power_pc_output = np.sum(ct.signal_power(predictions["pc_output"], 0))
        # power_noise_output = np.sum(ct.signal_power(predictions["noise_output"], 0))
        # print("Iteration:%6d/%-6d | training_SNR:%5f | loss:%8f | acc:%5f | power_x:%5f | power_pc_output:%5f | power_noise_output:%5f"
        #       % (itr, cfg.FLAGS.num_training, snr_train, loss, acc, power_x, power_pc_output, power_noise_output))
        if (itr != 0) and itr % PRINT_INTERVAL == 0:
            print("Iteration:%6d/%-6d | training_SNR:%5f | loss:%8f | acc:%5f | lr:%5f" % (itr, cfg.FLAGS.num_training, snr_train, loss, acc, lr))
            # print('t_bb_output_rank=%6d' % (np.linalg.matrix_rank(predictions["t_bb_output"])))
            # print('t_rf_output_rank=%6d' % (np.linalg.matrix_rank(predictions["t_rf_output"])))
            # print('pc_output_rank=%6d' % (np.linalg.matrix_rank(predictions["pc_output"])))
            # print('h_output_rank=%6d' % (np.linalg.matrix_rank(predictions["h_output"])))
            # print('h_rank=%6d' % (np.linalg.matrix_rank(predictions["h"])))
            # print('noise_output_rank=%6d' % (np.linalg.matrix_rank(predictions["noise_output"])))
            # print('r_rf_output_rank=%6d' % (np.linalg.matrix_rank(predictions["r_rf_output"])))
            # print('r_bb_output_rank=%6d' % (np.linalg.matrix_rank(predictions["r_bb_output"])))

        # # 星座图
        # plt.cla()
        # plt.scatter(np.real(predictions["r_rf_output"][:, 0]), np.imag(predictions["r_rf_output"][:, 1]), s=10)
        # # plt.scatter(np.real(datasets["scatter_std"]), np.imag(datasets["scatter_std"]), s=30)
        # plt.xlabel("Real")
        # plt.ylabel("Imag")
        # # plt.xlim(-0.5, 0.5)
        # # plt.ylim(-0.5, 0.5)
        #
        # plt.title("scatter figure of x after " + str(itr) + " trains,\nBER = " + str(1 - acc) + "\nSNR = " + str(snr_train) + "dB")
        # plt.pause(0.1)

        # loss_print.append(loss)
        # acc_print.append(acc)

        loss = result[-1]

        if save_flag == 1 and itr % PRINT_INTERVAL == 0:
            if loss < best_loss:
                best_loss = loss
                # print("saving model...")
                saver.save(sess, cfg.FLAGS.logdir + '/model' + str(itr))

        if itr % SUMMARY_INTERVAL == 0:
            if cfg.FLAGS.log:
                train_writer.add_summary(result[1], itr)

    # plt.ioff()
    # plt.show()
    # sio.savemat('Fast_itr_H2.mat', {'Fast_itR': iteration})
    # sio.savemat('Slow_loss', {'Slow_loss': loss_print})
    # sio.savemat('Slow_acc', {'Slow_acc': acc_print})
    # sio.savemat('t_bb_output', {'t_bb_output': predictions["t_bb_output"]})
    # sio.savemat('r_rf_output', {'r_rf_output': predictions["r_rf_output"]})

    if not cfg.FLAGS.pretrained_data_store:
        saver.save(sess, cfg.FLAGS.logdir + '\\model' + str(itr))
    else:
        saver.save(sess, cfg.FLAGS.store_data_pre + '\\pretrained_model' + str(itr))



# def test(model, sess, data_generator, channel):
#     n_frames = int(cfg.FLAGS.N_bits_test/data_generator.bit/cfg.FLAGS.Ns)
#     test_result ={}
#     BER = {}
#     x = []
#     y = []
#     # acc = np.zeros([10, 4])
#     acc = np.zeros([16, cfg.FLAGS.Ns])
#     # SNR = [10]
#     counter = 0
#     for snr in range(-15, 0, 1):
#
#         _, batch_x, _, scatter_std = data_generator.signal_generator([n_frames, model.Ns_total])
#         batch_noise = data_generator.noise_generator(1, snr, [n_frames, model.Nr_total])
#         batch_h = channel
#
#         feed_dict = {model.real_x: np.float32(np.real(batch_x)),
#                      model.imag_x: np.float32(np.imag(batch_x)),
#                      model.real_h: np.float32(np.real(batch_h)),
#                      model.imag_h: np.float32(np.imag(batch_h)),
#                      model.real_noise: np.float32(np.real(batch_noise)),
#                      model.imag_noise: np.float32(np.imag(batch_noise))
#                      }
#         input_tensors = [model.pre, model.x, model.predictions]
#         result = sess.run(input_tensors, feed_dict)
#         trans = result[0]
#         receive = result[1]
#         binary_real, _, _ = data_generator.signal_decoder(trans[:, 0])
#         binary_pred, _, _ = data_generator.signal_decoder(receive[:, 0])
#         # ACC1 = data_generator.count_accuracy_rate(binary_pred, binary_real)
#         # binary_real, _, _ = data_generator.signal_decoder(trans[:, 1])
#         # binary_pred, _, _ = data_generator.signal_decoder(receive[:, 1])
#         # ACC2 = data_generator.count_accuracy_rate(binary_pred, binary_real)
#         # print("SNR = " + str(snr) + " ,BER1 = " + str(1 - ACC1) + " ,BER2 = " + str(1 - ACC2))
#         binary_real, _, _ = data_generator.signal_decoder(result[0])
#         binary_pred, _, _ = data_generator.signal_decoder(result[1])
#         print(np.shape(binary_real))
#         print(np.shape(binary_pred))
#
#         for i in range(cfg.FLAGS.Ns):
#             m = i + i * cfg.FLAGS.N_bits_test
#             n = cfg.FLAGS.N_bits_test + i * cfg.FLAGS.N_bits_test - 1
#             acc[counter, i] = data_generator.count_accuracy_rate(binary_pred[:, m:n], binary_real[:, m:n])
#         x.append(snr)
#         y.append(1-acc)
#         print("SNR = " + str(snr) + " ,BER = " + str(1-acc))
#         test_result[str(snr)] = result[-1]
#         counter = counter + 1
#     BER["x"] = x
#     BER["y"] = y
#     # sal.save_pkl(cfg.FLAGS.path_for_test_results, test_result)
#     sio.savemat(cfg.FLAGS.path_for_ber, BER)
#     sal.save_pkl(cfg.FLAGS.path_for_ber, BER)

def test(model, sess, data_generator, channel):
    n_frames = int(cfg.FLAGS.N_bits_test/data_generator.bit/cfg.FLAGS.Ns)
    test_result ={}
    BER = {}
    x = []
    y = []
    # SNR = [10]
    for snr in range(-20, 1, 1):
        _, batch_x, _, scatter_std = data_generator.signal_generator([n_frames, model.Ns_total])
        batch_noise = data_generator.noise_generator(1, snr, [n_frames, model.Nr_total])
        batch_h = channel

        feed_dict = {model.real_x: np.float32(np.real(batch_x)),
                     model.imag_x: np.float32(np.imag(batch_x)),
                     model.real_h: np.float32(np.real(batch_h)),
                     model.imag_h: np.float32(np.imag(batch_h)),
                     model.real_noise: np.float32(np.real(batch_noise)),
                     model.imag_noise: np.float32(np.imag(batch_noise))
                     }
        input_tensors = [model.pre, model.x, model.predictions]
        result = sess.run(input_tensors, feed_dict)
        binary_real, _, _ = data_generator.signal_decoder(result[0])
        binary_pred, _, _ = data_generator.signal_decoder(result[1])
        acc = data_generator.count_accuracy_rate(binary_pred, binary_real)
        x.append(snr)
        y.append(1-acc)
        print("SNR = " + str(snr) + " ,BER = " + str(1-acc))
        test_result[str(snr)] = result[-1]
    BER["x"] = x
    BER["y"] = y
    # sal.save_pkl(cfg.FLAGS.path_for_test_results, test_result)
    sio.savemat(cfg.FLAGS.path_for_ber, BER)
    sal.save_pkl(cfg.FLAGS.path_for_ber, BER)

def load():

    data = sal.load_pkl(cfg.FLAGS.path_for_ber)
    sio.savemat(cfg.FLAGS.path_for_ber, data)
    return data


def main():
    # built model
    model = net.Cdnn()
    print(cfg.FLAGS.connected)
    print("System parameters:")
    print("K=%d, Ns=%d, Ntrf=%d, Nrrf=%d, Nt=%d, Nr=%d" % (model.K, model.Ns, model.Ntrf, model.Nrrf, model.Nt, model.Nr))
    # print("Network parameters:")
    # print("digital beamformer:", str(model.db_dim_list))
    # print("digital combiner:", str(model.dc_dim_list))
    model.summary_op = tf.summary.merge_all()

    saver = tf.train.Saver(tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES), max_to_keep=1)
    sess = tf.InteractiveSession()

    resume_itr = 0

    tf.global_variables_initializer().run()
    tf.train.start_queue_runners()

    data_generator = cttjy.signal(cfg.FLAGS.modulation_mode, cfg.FLAGS.power_normalization, model.Ns)
    if cfg.FLAGS.resume or not cfg.FLAGS.train:
        model_file = tf.train.latest_checkpoint(cfg.FLAGS.logdir)
        if model_file:
            ind1 = model_file.index('model')
            resume_itr = int(model_file[ind1+5:])
            print("Restoring model weights from " + model_file)
            saver.restore(sess, model_file)
    if cfg.FLAGS.train:
        train(model, saver, sess, data_generator, resume_itr)
    if cfg.FLAGS.test:
        hsets = sal.load_pkl(cfg.FLAGS.path_for_hsets)
        test(model, sess, data_generator, hsets["mimochan0"])


if __name__ == "__main__":
    # tf.set_random_seed(1024)
    # np.random.seed(1024)
    if not os.access("data/HB/"+cfg.FLAGS.connected, os.F_OK):
        os.makedirs("data/HB/" + cfg.FLAGS.connected)

    cfg.FLAGS.path_for_hsets = "data/HB/"+cfg.FLAGS.connected+"/hsets.pkl"
    cfg.FLAGS.logdir = "data/HB/"+cfg.FLAGS.connected+"/logdir"
    cfg.FLAGS.path_for_ber = "data/HB/"+cfg.FLAGS.connected+"/ber.pkl"
    # data = load()

    # loss_list = np.zeros([interval, cfg.FLAGS.num_training])
    # for i in range(interval):
    #     print("这是第 " + str(i) + " 轮")
    #     main(i)
    #     tf.reset_default_graph()

    main()
