import numpy as np
import lib.utils.quantization as qut
import tensorflow as tf
# a = [
#     [1,2,3]
#     ,
#     [4,5,6]
# ]
# b = np.reshape(a, (-1))
# for data in b:
#     print(data)
# print(b)


def construct_quadrant(parts):
    quadrant_list = []
    per = (2 * np.pi) / parts  # 精度间隔
    for index in range(parts):
        quadrant_value = index * per + per / 2
        quadrant_list.append(quadrant_value)

    return quadrant_list

def main():
    # a = tf.Variable(tf.zeros(6,5), name="wwe")
    # b= tf.get_variable("wwe")
    # sess = tf.Session()
    # print(sess.run(b))
    lr_list_temp = np.zeros([22, 2])
    print(lr_list_temp)




if __name__ == "__main__":
    main()