import tensorflow as tf
import lib.config.config_1BSNt_KUENr as cfg
import lib.utils.ljk_beamforming_tools as bt
import lib.utils.quantization as qut
import numpy as np
import os
from tensorflow.python import pywrap_tensorflow


class Cdnn_quant:
    """
    constrained neural networks of stand
    """
    def __init__(self, angle):
        """
        始化网络参数
        """
        self.K = 1
        self.N = 1
        self.Ns = cfg.FLAGS.Ns
        self.Nr = cfg.FLAGS.Nr
        self.Nt = cfg.FLAGS.Nt
        self.Ntrf = cfg.FLAGS.Ntrf
        self.Nrrf = cfg.FLAGS.Nrrf
        self.t_per = np.int(self.Nt/self.Ntrf)
        self.r_per = np.int(self.Nr/self.Nrrf)
        # 根据层数初始化
        self.tbb_l0 = self.Ns
        self.tbb_l1 = self.Ns * 2 * self.N
        self.tbb_l2 = self.Ntrf
        self.rbb_l0 = self.Nrrf
        self.rbb_l1 = self.Ns * 2 * self.N
        self.rbb_l2 = self.Ns

        # 激活函数
        self.activation = tf.nn.tanh
        # placeholder
        self.real_x = tf.placeholder(tf.float32, [None, self.Ns])
        self.imag_x = tf.placeholder(tf.float32, [None, self.Ns])
        self.real_h = tf.placeholder(tf.float32, [self.Nt, self.Nr])
        self.imag_h = tf.placeholder(tf.float32, [self.Nt, self.Nr])
        self.real_noise = tf.placeholder(tf.float32, [None, self.Nr])
        self.imag_noise = tf.placeholder(tf.float32, [None, self.Nr])
        self.lr = tf.placeholder(tf.float32)
        self.quantization = qut.Quantization(angle * 2)

        # construct_model
        # 存储中间数据
        self.predictions = {}
        # self.parameters_q = parameters_q
        # self.parameters = self.construct_parameters()
        self.real_pre, self.imag_pre = self.forward_basic_ternary(self.real_x, self.imag_x, self.real_h, self.imag_h, self.real_noise, self.imag_noise, self.construct_parameters(self.quantization), angle)
        self.loss = self.loss_fn(self.real_pre, self.imag_pre, self.real_x, self.imag_x)
        self.summary_predictions()
        # 通知 tensorflow 在训练时要更新均值的方差的分布
        self.train_op = tf.train.AdamOptimizer(self.lr).minimize(self.loss)
        # update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        # with tf.control_dependencies(update_ops):
        #     self.train_op = tf.train.AdamOptimizer(self.lr).minimize(self.loss)
        #     # self.train_op = tf.train.MomentumOptimizer(cfg.FLAGS.lr, 0.001).minimize(self.loss)
        #     # self.train_op = tf.train.GradientDescentOptimizer(cfg.FLAGS.lr).minimize(self.loss)

        self.x = tf.complex(self.real_x, self.imag_x)
        self.pre = tf.complex(self.real_pre, self.imag_pre)

    def forward_basic_ternary(self, real_x, imag_x, real_h, imag_h, real_noise, imag_noise, parameters, angle):
        """

        :param real_x:
        :param imag_x:
        :param real_h:
        :param imag_h:
        :param real_noise:
        :param imag_noise:
        :param parameters:
        :return:
        """
        # complex value of the inputs
        x = tf.complex(real_x, imag_x, name="x")
        h = tf.complex(real_h, imag_h, name="h")
        noise = tf.complex(real_noise, imag_noise, name="noise")


        # build network
        with tf.name_scope('baseband_beamforming'):
            with tf.name_scope('real_channel'):    # 只有一层的时候，ternary的表现非常好
                t_real_l1 = self.activation(tf.matmul(real_x, parameters["t_real_l1_weights"]) + parameters["t_real_l1_biases"], name="t_real_l1")
                t_real_l2 = self.activation(tf.matmul(t_real_l1, parameters["t_real_l2_weights"]) + parameters["t_real_l2_biases"], name="t_real_l2")
                real_baseband_output = t_real_l2
            with tf.name_scope('imag_channel'):
                t_imag_l1 = self.activation(tf.matmul(imag_x, parameters["t_imag_l1_weights"]) + parameters["t_imag_l1_biases"], name="t_imag_l1")
                t_imag_l2 = self.activation(tf.matmul(t_imag_l1, parameters["t_imag_l2_weights"]) + parameters["t_imag_l2_biases"], name="t_imag_l2")
                imag_baseband_output = t_imag_l2
            # output of baseband beamforming
            t_bb_output = tf.complex(real_baseband_output, imag_baseband_output, name="baseband_beamforming_output")

        with tf.name_scope('rf_beamforming'):
            theta_t = parameters["theta_t"]
            # print("发射量化")
            # 共有Ntrf个floor，修改Ntrf的时候，记得修改下列代码
            t_real_rf_f1, t_imag_rf_f1 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 0], (-1, 1)), tf.reshape(imag_baseband_output[:, 0], (-1, 1)), tf.reshape(theta_t[0, :], (1, -1)), name='t_real_rf_f1')
            t_real_rf_f2, t_imag_rf_f2 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 1], (-1, 1)), tf.reshape(imag_baseband_output[:, 1], (-1, 1)), tf.reshape(theta_t[1, :], (1, -1)), name='t_real_rf_f2')
            t_real_rf_f3, t_imag_rf_f3 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 2], (-1, 1)), tf.reshape(imag_baseband_output[:, 2], (-1, 1)), tf.reshape(theta_t[2, :], (1, -1)), name='t_real_rf_f3')
            t_real_rf_f4, t_imag_rf_f4 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 3], (-1, 1)), tf.reshape(imag_baseband_output[:, 3], (-1, 1)), tf.reshape(theta_t[3, :], (1, -1)), name='t_real_rf_f4')
            # t_real_rf_f5, t_imag_rf_f5 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 4], (-1, 1)), tf.reshape(imag_baseband_output[:, 4], (-1, 1)), tf.reshape(theta_t[4, :], (1, -1)), name='t_real_rf_f5')
            # t_real_rf_f6, t_imag_rf_f6 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 5], (-1, 1)), tf.reshape(imag_baseband_output[:, 5], (-1, 1)), tf.reshape(theta_t[5, :], (1, -1)), name='t_real_rf_f6')
            # t_real_rf_f7, t_imag_rf_f7 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 6], (-1, 1)), tf.reshape(imag_baseband_output[:, 6], (-1, 1)), tf.reshape(theta_t[6, :], (1, -1)), name='t_real_rf_f7')
            # t_real_rf_f8, t_imag_rf_f8 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 7], (-1, 1)), tf.reshape(imag_baseband_output[:, 7], (-1, 1)), tf.reshape(theta_t[7, :], (1, -1)), name='t_real_rf_f8')
            # t_real_rf_f9, t_imag_rf_f9 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 8], (-1, 1)), tf.reshape(imag_baseband_output[:, 8], (-1, 1)), tf.reshape(theta_t[8, :], (1, -1)), name='t_real_rf_f9')
            # t_real_rf_f10, t_imag_rf_f10 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 9], (-1, 1)), tf.reshape(imag_baseband_output[:, 9], (-1, 1)), tf.reshape(theta_t[9, :], (1, -1)), name='t_real_rf_f10')
            # t_real_rf_f11, t_imag_rf_f11 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 10], (-1, 1)), tf.reshape(imag_baseband_output[:, 10], (-1, 1)), tf.reshape(theta_t[10, :], (1, -1)), name='t_real_rf_f11')
            # t_real_rf_f12, t_imag_rf_f12 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 11], (-1, 1)), tf.reshape(imag_baseband_output[:, 11], (-1, 1)), tf.reshape(theta_t[11, :], (1, -1)), name='t_real_rf_f12')
            # t_real_rf_f13, t_imag_rf_f13 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 12], (-1, 1)), tf.reshape(imag_baseband_output[:, 12], (-1, 1)), tf.reshape(theta_t[12, :], (1, -1)), name='t_real_rf_f13')
            # t_real_rf_f14, t_imag_rf_f14 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 13], (-1, 1)), tf.reshape(imag_baseband_output[:, 13], (-1, 1)), tf.reshape(theta_t[13, :], (1, -1)), name='t_real_rf_f14')
            # t_real_rf_f15, t_imag_rf_f15 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 14], (-1, 1)), tf.reshape(imag_baseband_output[:, 14], (-1, 1)), tf.reshape(theta_t[14, :], (1, -1)), name='t_real_rf_f15')
            # t_real_rf_f16, t_imag_rf_f16 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 15], (-1, 1)), tf.reshape(imag_baseband_output[:, 15], (-1, 1)), tf.reshape(theta_t[15, :], (1, -1)), name='t_real_rf_f16')
            # t_real_rf_f17, t_imag_rf_f17 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 16], (-1, 1)), tf.reshape(imag_baseband_output[:, 16], (-1, 1)), tf.reshape(theta_t[16, :], (1, -1)), name='t_real_rf_f17')
            # t_real_rf_f18, t_imag_rf_f18 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 17], (-1, 1)), tf.reshape(imag_baseband_output[:, 17], (-1, 1)), tf.reshape(theta_t[17, :], (1, -1)), name='t_real_rf_f18')
            # t_real_rf_f19, t_imag_rf_f19 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 18], (-1, 1)), tf.reshape(imag_baseband_output[:, 18], (-1, 1)), tf.reshape(theta_t[18, :], (1, -1)), name='t_real_rf_f19')
            # t_real_rf_f20, t_imag_rf_f20 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 19], (-1, 1)), tf.reshape(imag_baseband_output[:, 19], (-1, 1)), tf.reshape(theta_t[19, :], (1, -1)), name='t_real_rf_f20')
            # t_real_rf_f21, t_imag_rf_f21 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 20], (-1, 1)), tf.reshape(imag_baseband_output[:, 20], (-1, 1)), tf.reshape(theta_t[20, :], (1, -1)), name='t_real_rf_f21')
            # t_real_rf_f22, t_imag_rf_f22 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 21], (-1, 1)), tf.reshape(imag_baseband_output[:, 21], (-1, 1)), tf.reshape(theta_t[21, :], (1, -1)), name='t_real_rf_f22')
            # t_real_rf_f23, t_imag_rf_f23 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 22], (-1, 1)), tf.reshape(imag_baseband_output[:, 22], (-1, 1)), tf.reshape(theta_t[22, :], (1, -1)), name='t_real_rf_f23')
            # t_real_rf_f24, t_imag_rf_f24 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 23], (-1, 1)), tf.reshape(imag_baseband_output[:, 23], (-1, 1)), tf.reshape(theta_t[23, :], (1, -1)), name='t_real_rf_f24')
            # t_real_rf_f25, t_imag_rf_f25 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 24], (-1, 1)), tf.reshape(imag_baseband_output[:, 24], (-1, 1)), tf.reshape(theta_t[24, :], (1, -1)), name='t_real_rf_f25')
            # t_real_rf_f26, t_imag_rf_f26 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 25], (-1, 1)), tf.reshape(imag_baseband_output[:, 25], (-1, 1)), tf.reshape(theta_t[25, :], (1, -1)), name='t_real_rf_f26')
            # t_real_rf_f27, t_imag_rf_f27 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 26], (-1, 1)), tf.reshape(imag_baseband_output[:, 26], (-1, 1)), tf.reshape(theta_t[26, :], (1, -1)), name='t_real_rf_f27')
            # t_real_rf_f28, t_imag_rf_f28 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 27], (-1, 1)), tf.reshape(imag_baseband_output[:, 27], (-1, 1)), tf.reshape(theta_t[27, :], (1, -1)), name='t_real_rf_f28')
            # t_real_rf_f29, t_imag_rf_f29 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 28], (-1, 1)), tf.reshape(imag_baseband_output[:, 28], (-1, 1)), tf.reshape(theta_t[28, :], (1, -1)), name='t_real_rf_f29')
            # t_real_rf_f30, t_imag_rf_f30 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 29], (-1, 1)), tf.reshape(imag_baseband_output[:, 29], (-1, 1)), tf.reshape(theta_t[29, :], (1, -1)), name='t_real_rf_f30')
            # t_real_rf_f31, t_imag_rf_f31 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 30], (-1, 1)), tf.reshape(imag_baseband_output[:, 30], (-1, 1)), tf.reshape(theta_t[30, :], (1, -1)), name='t_real_rf_f31')
            # t_real_rf_f32, t_imag_rf_f32 = bt.phase_shift_matmul(tf.reshape(real_baseband_output[:, 31], (-1, 1)), tf.reshape(imag_baseband_output[:, 31], (-1, 1)), tf.reshape(theta_t[31, :], (1, -1)), name='t_real_rf_f32')

            #  concat
            t_real_rf_output = tf.concat([t_real_rf_f1, t_real_rf_f2,t_real_rf_f3,t_real_rf_f4], 1, name="t_real_rf_output")
                                             # ,t_real_rf_f5,t_real_rf_f6,t_real_rf_f7,t_real_rf_f8,t_real_rf_f9,t_real_rf_f10,t_real_rf_f11,t_real_rf_f12,t_real_rf_f13,t_real_rf_f14,t_real_rf_f15,t_real_rf_f16,t_real_rf_f17,t_real_rf_f18,t_real_rf_f19,t_real_rf_f20,t_real_rf_f21,t_real_rf_f22,t_real_rf_f23,t_real_rf_f24,t_real_rf_f25,t_real_rf_f26,t_real_rf_f27,t_real_rf_f28,t_real_rf_f29,t_real_rf_f30,t_real_rf_f31, t_real_rf_f32], 1, name="t_real_rf_output")
            t_imag_rf_output = tf.concat([t_imag_rf_f1, t_imag_rf_f2,t_imag_rf_f3,t_imag_rf_f4], 1, name="t_imag_rf_output")
                                                                            # ,t_imag_rf_f5,t_imag_rf_f6,t_imag_rf_f7,t_imag_rf_f8,t_imag_rf_f9,t_imag_rf_f10,t_imag_rf_f11,t_imag_rf_f12,t_imag_rf_f13,t_imag_rf_f14,t_imag_rf_f15,t_imag_rf_f16,t_imag_rf_f17,t_imag_rf_f18,t_imag_rf_f19,t_imag_rf_f20,t_imag_rf_f21,t_imag_rf_f22,t_imag_rf_f23,t_imag_rf_f24,t_imag_rf_f25,t_imag_rf_f26,t_imag_rf_f27,t_imag_rf_f28,t_imag_rf_f29,t_imag_rf_f30,t_imag_rf_f31, t_imag_rf_f32], 1, name="t_imag_rf_output")
            # RF beamforming output
            t_rf_output = tf.complex(t_real_rf_output, t_imag_rf_output, name="rf_beamforming_output")

        with tf.name_scope('power_constrained'):
            real_pc_output, imag_pc_output = bt.power_constrained(t_real_rf_output, t_imag_rf_output, True)
            # power_constrained_output
            pc_output = tf.complex(real_pc_output, imag_pc_output, name="pc_output")

        with tf.name_scope('channel_transmission'):
            # 过传输矩阵H
            h_real_temp = tf.matmul(real_pc_output, real_h, name="RxR") - tf.matmul(imag_pc_output, imag_h, name="IxI")
            h_imag_temp = tf.matmul(real_pc_output, imag_h, name="RxI") + tf.matmul(imag_pc_output, real_h, name="IxR")
            # h_output
            h_output = tf.complex(h_real_temp, h_imag_temp, name="h_output")
        # add noise
        with tf.name_scope("add_noise"):
            real_noise_output = tf.add(h_real_temp, real_noise, name="real")
            imag_noise_output = tf.add(h_imag_temp, imag_noise, name="imag")
            # noise_output
            noise_output = tf.complex(real_noise_output, imag_noise_output, name="noise_output")

        with tf.name_scope('rf_combining'):
            n_d1 = self.r_per
            theta_r = parameters["theta_r"]
            # print("接收量化")
            r_real_rf_f1, r_imag_rf_f1 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 0 * n_d1:1 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 0 * n_d1:1 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 0], (-1, 1)), name='r_rf_f1')
            r_real_rf_f2, r_imag_rf_f2 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 1 * n_d1:2 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 1 * n_d1:2 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 1], (-1, 1)), name='r_rf_f2')
            r_real_rf_f3, r_imag_rf_f3 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 2 * n_d1:3 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 2 * n_d1:3 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 2], (-1, 1)), name='r_rf_f3')
            r_real_rf_f4, r_imag_rf_f4 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 3 * n_d1:4 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 3 * n_d1:4 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 3], (-1, 1)), name='r_rf_f4')
            # r_real_rf_f5, r_imag_rf_f5 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 4 * n_d1:5 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 4 * n_d1:5 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 4], (-1, 1)), name='r_rf_f5')
            # r_real_rf_f6, r_imag_rf_f6 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 5 * n_d1:6 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 5 * n_d1:6 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 5], (-1, 1)), name='r_rf_f6')
            # r_real_rf_f7, r_imag_rf_f7 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 6 * n_d1:7 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 6 * n_d1:7 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 6], (-1, 1)), name='r_rf_f7')
            # r_real_rf_f8, r_imag_rf_f8 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 7 * n_d1:8 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 7 * n_d1:8 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 7], (-1, 1)), name='r_rf_f8')
            # r_real_rf_f9, r_imag_rf_f9 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 8 * n_d1:9 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 8 * n_d1:9 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 8], (-1, 1)), name='r_rf_f9')
            # r_real_rf_f10, r_imag_rf_f10 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 9 * n_d1:10 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 9 * n_d1:10 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 9], (-1, 1)), name='r_rf_f10')
            # r_real_rf_f11, r_imag_rf_f11 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 10 * n_d1:11 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 10 * n_d1:11 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 10], (-1, 1)), name='r_rf_f11')
            # r_real_rf_f12, r_imag_rf_f12 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 11 * n_d1:12 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 11 * n_d1:12 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 11], (-1, 1)), name='r_rf_f12')
            # r_real_rf_f13, r_imag_rf_f13 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 12 * n_d1:13 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 12 * n_d1:13 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 12], (-1, 1)), name='r_rf_f13')
            # r_real_rf_f14, r_imag_rf_f14 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 13 * n_d1:14 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 13 * n_d1:14 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 13], (-1, 1)), name='r_rf_f14')
            # r_real_rf_f15, r_imag_rf_f15 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 14 * n_d1:15 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 14 * n_d1:15 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 14], (-1, 1)), name='r_rf_f15')
            # r_real_rf_f16, r_imag_rf_f16 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 15 * n_d1:16 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 15 * n_d1:16 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 15], (-1, 1)), name='r_rf_f16')
            # r_real_rf_f17, r_imag_rf_f17 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 16 * n_d1:17 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 16 * n_d1:17 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 16], (-1, 1)), name='r_rf_f17')
            # r_real_rf_f18, r_imag_rf_f18 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 17 * n_d1:18 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 17 * n_d1:18 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 17], (-1, 1)), name='r_rf_f18')
            # r_real_rf_f19, r_imag_rf_f19 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 18 * n_d1:19 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 18 * n_d1:19 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 18], (-1, 1)), name='r_rf_f19')
            # r_real_rf_f20, r_imag_rf_f20 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 19 * n_d1:20 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 19 * n_d1:20 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 19], (-1, 1)), name='r_rf_f20')
            # r_real_rf_f21, r_imag_rf_f21 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 20 * n_d1:21 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 20 * n_d1:21 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 20], (-1, 1)), name='r_rf_f21')
            # r_real_rf_f22, r_imag_rf_f22 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 21 * n_d1:22 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 21 * n_d1:22 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 21], (-1, 1)), name='r_rf_f22')
            # r_real_rf_f23, r_imag_rf_f23 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 22 * n_d1:23 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 22 * n_d1:23 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 22], (-1, 1)), name='r_rf_f23')
            # r_real_rf_f24, r_imag_rf_f24 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 23 * n_d1:24 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 23 * n_d1:24 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 23], (-1, 1)), name='r_rf_f24')
            # r_real_rf_f25, r_imag_rf_f25 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 24 * n_d1:25 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 24 * n_d1:25 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 24], (-1, 1)), name='r_rf_f25')
            # r_real_rf_f26, r_imag_rf_f26 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 25 * n_d1:26 * n_d1], (-1, n_d1)),tf.reshape(imag_noise_output[:, 25 * n_d1:26 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 25], (-1, 1)), name='r_rf_f26')
            # r_real_rf_f27, r_imag_rf_f27 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 26 * n_d1:27 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 26 * n_d1:27 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 26], (-1, 1)), name='r_rf_f27')
            # r_real_rf_f28, r_imag_rf_f28 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 27 * n_d1:28 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 27 * n_d1:28 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 27], (-1, 1)), name='r_rf_f28')
            # r_real_rf_f29, r_imag_rf_f29 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 28 * n_d1:29 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 28 * n_d1:29 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 28], (-1, 1)), name='r_rf_f29')
            # r_real_rf_f30, r_imag_rf_f30 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 29 * n_d1:30 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 29 * n_d1:30 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 29], (-1, 1)), name='r_rf_f30')
            # r_real_rf_f31, r_imag_rf_f31 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 30 * n_d1:31 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 30 * n_d1:31 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 30], (-1, 1)), name='r_rf_f31')
            # r_real_rf_f32, r_imag_rf_f32 = bt.phase_shift_matmul(tf.reshape(real_noise_output[:, 31 * n_d1:32 * n_d1], (-1, n_d1)), tf.reshape(imag_noise_output[:, 31 * n_d1:32 * n_d1], (-1, n_d1)), tf.reshape(theta_r[:, 31], (-1, 1)), name='r_rf_f32')

            #  concat
            r_real_rf_output = tf.concat([r_real_rf_f1,r_real_rf_f2,r_real_rf_f3,r_real_rf_f4], 1, name="r_real_rf_output")
                                             # ,r_real_rf_f5,r_real_rf_f6,r_real_rf_f7,r_real_rf_f8,r_real_rf_f9,r_real_rf_f10,r_real_rf_f11,r_real_rf_f12,r_real_rf_f13,r_real_rf_f14,r_real_rf_f15,r_real_rf_f16,r_real_rf_f17,r_real_rf_f18,r_real_rf_f19,r_real_rf_f20,r_real_rf_f21,r_real_rf_f22,r_real_rf_f23,r_real_rf_f24,r_real_rf_f25,r_real_rf_f26,r_real_rf_f27,r_real_rf_f28,r_real_rf_f29,r_real_rf_f30,r_real_rf_f31,r_real_rf_f32], 1, name="r_real_rf_output")
            r_imag_rf_output = tf.concat([r_imag_rf_f1,r_imag_rf_f2,r_imag_rf_f3,r_imag_rf_f4], 1, name="r_imag_rf_output")
                                             # ,r_imag_rf_f5,r_imag_rf_f6,r_imag_rf_f7,r_imag_rf_f8,r_imag_rf_f9,r_imag_rf_f10,r_imag_rf_f11,r_imag_rf_f12,r_imag_rf_f13,r_imag_rf_f14,r_imag_rf_f15,r_imag_rf_f16,r_imag_rf_f17,r_imag_rf_f18,r_imag_rf_f19,r_imag_rf_f20,r_imag_rf_f21,r_imag_rf_f22,r_imag_rf_f23,r_imag_rf_f24,r_imag_rf_f25,r_imag_rf_f26,r_imag_rf_f27,r_imag_rf_f28,r_imag_rf_f29,r_imag_rf_f30,r_imag_rf_f31,r_imag_rf_f32], 1, name="r_imag_rf_output")
            # RF combining output

        # with tf.name_scope("quantize"):
        #     print("ternary")
        #     r_real_rf_output = bt.ternary_operation(r_real_rf_output)
        #     r_imag_rf_output = bt.ternary_operation(r_imag_rf_output)
            r_rf_output = tf.complex(r_real_rf_output, r_imag_rf_output, name="rf_combining_output")

        with tf.name_scope('baseband_combining'):
            with tf.name_scope('real_channel'):
                r_real_l1 = self.activation(tf.matmul(r_real_rf_output, parameters["r_real_l1_weights"]) + parameters["r_real_l1_biases"], name="r_real_l1")
                r_real_l2 = self.activation(tf.matmul(r_real_l1, parameters["r_real_l2_weights"]) + parameters["r_real_l2_biases"], name="r_real_l1")
                real_prediction = r_real_l2
            with tf.name_scope('imag_channel'):
                r_imag_l1 = self.activation(tf.matmul(r_imag_rf_output, parameters["r_imag_l1_weights"]) + parameters["r_imag_l1_biases"], name="r_imag_l1")
                r_imag_l2 = self.activation(tf.matmul(r_imag_l1, parameters["r_imag_l2_weights"]) + parameters["r_imag_l2_biases"], name="r_imag_l1")
                imag_prediction = r_imag_l2
            r_bb_output = tf.complex(real_prediction, imag_prediction, name="output")

        self.predictions["t_bb_output"] = t_bb_output
        self.predictions["t_rf_output"] = t_rf_output
        self.predictions["pc_output"] = pc_output
        self.predictions["h_output"] = h_output
        self.predictions["noise_output"] = noise_output
        self.predictions["r_real_rf_output"] = r_real_rf_output    # 关注这个值
        self.predictions["r_rf_output"] = r_rf_output              # 关注这个值
        self.predictions["r_imag_rf_output"] = r_imag_rf_output    # 关注这个值
        self.predictions["r_bb_output"] = r_bb_output
        self.predictions["x"] = x
        self.predictions["noise"] = noise
        self.predictions["theta_t"] = theta_t
        self.predictions["theta_r"] = theta_r
        # self.predictions["theta_t1"] = theta_t1
        # self.predictions["theta_r1"] = theta_r1

        return real_prediction, imag_prediction

    def construct_parameters(self, quantization):
        parameters = {}
        # 变量初始化
        if not cfg.FLAGS.parameter_select:
            parameters["t_real_l1_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l0, self.tbb_l1], stddev=0.01), name="t_real_l1_weights")  # 0:1
            parameters["t_real_l1_biases"] = tf.Variable(tf.zeros([self.tbb_l1]), name="t_real_l1_biases")  # 1:2
            parameters["t_real_l2_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l1, self.tbb_l2], stddev=0.01), name="t_real_l2_weights")  # 2:3
            parameters["t_real_l2_biases"] = tf.Variable(tf.zeros([self.tbb_l2]), name="t_real_l2_biases")  # 3:4

            parameters["t_imag_l1_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l0, self.tbb_l1], stddev=0.01), name="t_imag_l1_weights")  # 4:5
            parameters["t_imag_l1_biases"] = tf.Variable(tf.zeros([self.tbb_l1]), name="t_imag_l1_biases")  # 5:6
            parameters["t_imag_l2_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l1, self.tbb_l2], stddev=0.01), name="t_imag_l2_weights")  # 6:7
            parameters["t_imag_l2_biases"] = tf.Variable(tf.zeros([self.tbb_l2]), name="t_imag_l2_biases")  # 7:8

            parameters["theta_t"] = tf.Variable(tf.random_uniform([self.Ntrf, self.t_per], minval=0, maxval=2 * np.pi), name="theta_t")  # 8:9
            parameters["theta_r"] = tf.Variable(tf.random_uniform([self.r_per, self.Nrrf], minval=0, maxval=2 * np.pi), name="theta_r")  # 9:10

            parameters["r_real_l1_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l0, self.rbb_l1], stddev=0.01), name="r_real_l1_weights")  # 10:11
            parameters["r_real_l1_biases"] = tf.Variable(tf.zeros([self.rbb_l1]), name="r_real_l1_biases")  # 11:12
            parameters["r_real_l2_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l1, self.rbb_l2], stddev=0.01), name="r_real_l2_weights")  # 12:13
            parameters["r_real_l2_biases"] = tf.Variable(tf.zeros([self.rbb_l2]), name="r_real_l2_biases")  # 13:14

            parameters["r_imag_l1_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l0, self.rbb_l1], stddev=0.01), name="r_imag_l1_weights")  # 14:15
            parameters["r_imag_l1_biases"] = tf.Variable(tf.zeros([self.rbb_l1]), name="r_imag_l1_biases")  # 15:16
            parameters["r_imag_l2_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l1, self.rbb_l2], stddev=0.01), name="r_imag_l2_weights")  # 16:17
            parameters["r_imag_l2_biases"] = tf.Variable(tf.zeros([self.rbb_l2]), name="r_imag_l2_biases")  # 17:18
        else:
            model_dir = ""
            checkpoint_path = os.path.join(model_dir, "original/pi_15000/data_quant/QAM/mimochannel_less/logdir\\model7999")
            # Read data from checkpoint file
            reader = pywrap_tensorflow.NewCheckpointReader(checkpoint_path)
            var_to_shape_map = reader.get_variable_to_shape_map()
            # Print tensor name and values
            sess = tf.Session()
            for key in var_to_shape_map:
                if key == "theta_t":

                    theta_t_quant = sess.run(quantization.quantificat(reader.get_tensor(key)))
                    input_reshape = np.reshape(theta_t_quant, (-1))
                    temp = []
                    for i in range(len(input_reshape)):
                        temp.append(input_reshape[i])
                    theta_t_constant = np.reshape(temp, (self.Ntrf, self.t_per))
                    print(theta_t_constant)

                    parameters[key] = tf.constant(theta_t_constant, name=key)
                elif key == "theta_r":

                    theta_r_quant = sess.run(quantization.quantificat(reader.get_tensor(key)))
                    # print(theta_r_quant)
                    input_reshape = np.reshape(theta_r_quant, (-1))
                    temp = []
                    for i in range(len(input_reshape)):
                        temp.append(input_reshape[i])
                    theta_r_constant = np.reshape(temp, (self.r_per, self.Nrrf))
                    print(theta_r_constant)

                    parameters[key] = tf.constant(theta_r_constant, name=key)
                else:
                    parameters[key] = tf.Variable(reader.get_tensor(key), name=key)

                print(parameters[key])

        return parameters

    def summary_predictions(self):
        for key in self.predictions:
            tf.summary.scalar("power_" + key, bt.signal_power_tf(self.predictions[key], 0))
            tf.summary.histogram("abs_" + key, tf.reshape(tf.abs(self.predictions[key]), [1, -1]))
        # loss
        tf.summary.scalar("loss", self.loss)

    def loss_fn(self, real_inputs, imag_inputs,  real_labels, imag_labels):
        loss = tf.reduce_mean(tf.square(real_inputs-real_labels) + tf.square(imag_inputs-imag_labels))
        return loss


# class Parameter_Construction:
#     def __init__(self):
#         self.K = 1
#         self.N = 1
#         self.Ns = cfg.FLAGS.Ns
#         self.Nr = cfg.FLAGS.Nr
#         self.Nt = cfg.FLAGS.Nt
#         self.Ntrf = cfg.FLAGS.Ntrf
#         self.Nrrf = cfg.FLAGS.Nrrf
#         self.tbb_l0 = self.Ns
#         self.tbb_l1 = self.Ns * 2 * self.N
#         self.tbb_l2 = self.Ntrf
#         self.rbb_l0 = self.Nrrf
#         self.rbb_l1 = self.Ns * 2 * self.N
#         self.rbb_l2 = self.Ns
#         self.t_per = np.int(self.Nt / self.Ntrf)
#         self.r_per = np.int(self.Nr / self.Nrrf)
#         self.parameters = self.construct_pre_parameters()
#
#     def construct_pre_parameters(self):
#         parameters = {}
#         # 变量初始化
#         # parameters["t_real_l1_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l0, self.tbb_l2], stddev=0.01), name="t_real_l1_weights")
#         # parameters["t_real_l1_biases"] = tf.Variable(tf.zeros([self.tbb_l2]), name="t_real_l1_biases")
#         #
#         # parameters["t_imag_l1_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l0, self.tbb_l2], stddev=0.01), name="t_imag_l1_weights")
#         # parameters["t_imag_l1_biases"] = tf.Variable(tf.zeros([self.tbb_l2]), name="t_imag_l1_biases")
#         #
#         # parameters["theta_t"] = tf.Variable(tf.random_uniform([self.Ntrf, self.t_per], minval=0, maxval=2 * np.pi), name="theta_t")
#         # parameters["theta_r"] = tf.Variable(tf.random_uniform([self.r_per, self.Nrrf], minval=0, maxval=2 * np.pi), name="theta_r")
#         #
#         # parameters["r_real_l1_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l0, self.rbb_l2], stddev=0.01), name="r_real_l1_weights")
#         # parameters["r_real_l1_biases"] = tf.Variable(tf.zeros([self.rbb_l2]), name="r_real_l1_biases")
#         #
#         # parameters["r_imag_l1_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l0, self.rbb_l2], stddev=0.01), name="r_imag_l1_weights")
#         # parameters["r_imag_l1_biases"] = tf.Variable(tf.zeros([self.rbb_l2]), name="r_imag_l1_biases")
#
#         parameters["t_real_l1_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l0, self.tbb_l1], stddev=0.01))
#         parameters["t_real_l1_biases"] = tf.Variable(tf.zeros([self.tbb_l1]))
#         parameters["t_real_l2_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l1, self.tbb_l2], stddev=0.01))
#         parameters["t_real_l2_biases"] = tf.Variable(tf.zeros([self.tbb_l2]))
#
#         parameters["t_imag_l1_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l0, self.tbb_l1], stddev=0.01))
#         parameters["t_imag_l1_biases"] = tf.Variable(tf.zeros([self.tbb_l1]))
#         parameters["t_imag_l2_weights"] = tf.Variable(tf.truncated_normal([self.tbb_l1, self.tbb_l2], stddev=0.01))
#         parameters["t_imag_l2_biases"] = tf.Variable(tf.zeros([self.tbb_l2]))
#
#         parameters["theta_t"] = tf.Variable(tf.random_uniform([self.Ntrf, self.t_per], minval=0, maxval=2 * np.pi), name="theta_t")
#         parameters["theta_r"] = tf.Variable(tf.random_uniform([self.r_per, self.Nrrf], minval=0, maxval=2 * np.pi), name="theta_r")
#
#         parameters["r_real_l1_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l0, self.rbb_l1], stddev=0.01))
#         parameters["r_real_l1_biases"] = tf.Variable(tf.zeros([self.rbb_l1]))
#         parameters["r_real_l2_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l1, self.rbb_l2], stddev=0.01))
#         parameters["r_real_l2_biases"] = tf.Variable(tf.zeros([self.rbb_l2]))
#
#         parameters["r_imag_l1_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l0, self.rbb_l1], stddev=0.01))
#         parameters["r_imag_l1_biases"] = tf.Variable(tf.zeros([self.rbb_l1]))
#         parameters["r_imag_l2_weights"] = tf.Variable(tf.truncated_normal([self.rbb_l1, self.rbb_l2], stddev=0.01))
#         parameters["r_imag_l2_biases"] = tf.Variable(tf.zeros([self.rbb_l2]))
#
#         return parameters
