import tensorflow as tf
import lib.config.config_1BSNt_KUENr as cfg
import lib.utils.beamforming_tools as bt
import numpy as np


class Cdnn:
    """
    constrained neural networks of stand
    """
    def __init__(self):
        """
        始化网络参数
        """
        # system parameters
        self.K = cfg.FLAGS.K
        self.Ns = cfg.FLAGS.Ns
        self.Nrrf = cfg.FLAGS.Nrrf
        self.Nr = cfg.FLAGS.Nr
        self.Nt = cfg.FLAGS.Nt
        self.Ns_total = self.K * self.Ns
        self.Nr_total = self.K * self.Nr
        self.Ntrf = self.K * self.Nrrf

        # network parameters
        # digital beamformer
        self.db_dim_list = [self.Nt*2, self.Nt*4, self.Nt*8, self.Nt*4, self.Nt]
        self.db_activation_list = [tf.nn.tanh, tf.nn.tanh, tf.nn.tanh, tf.nn.tanh, tf.nn.tanh]
        # digital combiner
        self.dc_dim_list = [self.Nt, self.Nt * 2, self.Nt, self.Ns]
        self.dc_activation_list = [tf.nn.tanh, tf.nn.tanh, tf.nn.tanh, tf.nn.tanh]

        # placeholder
        self.real_x = tf.placeholder(tf.float32, [None, self.Ns_total])
        self.imag_x = tf.placeholder(tf.float32, [None, self.Ns_total])
        self.real_h = tf.placeholder(tf.float32, [self.Nt, self.Nr_total])
        self.imag_h = tf.placeholder(tf.float32, [self.Nt, self.Nr_total])
        self.real_noise = tf.placeholder(tf.float32, [None, self.Nr_total])
        self.imag_noise = tf.placeholder(tf.float32, [None, self.Nr_total])
        self.lr = tf.placeholder(tf.float32)

        # construct_model
        self.predictions = {}   # 存储中间数据
        self.real_pre, self.imag_pre = self.forward_stand(self.real_x, self.imag_x, self.real_h, self.imag_h, self.real_noise, self.imag_noise)
        # self.real_pre, self.imag_pre = self.forward_basic(self.real_x, self.imag_x, self.real_h, self.imag_h, self.real_noise, self.imag_noise, self.construct_parameters())
        self.loss = self.loss_fn(self.real_pre, self.imag_pre, self.real_x, self.imag_x)
        self.summary_predictions()
        self.train_op = tf.train.AdamOptimizer(self.lr).minimize(self.loss)
        # self.train_op = tf.train.MomentumOptimizer(cfg.FLAGS.lr, 0.001).minimize(self.loss)
        # self.train_op = tf.train.GradientDescentOptimizer(cfg.FLAGS.lr).minimize(self.loss)
        self.x = tf.complex(self.real_x, self.imag_x)
        self.pre = tf.complex(self.real_pre, self.imag_pre)

    def forward_stand(self, real_x, imag_x, real_h, imag_h, real_noise, imag_noise):
        """
        stand forward process   ----  written with tf.layers()
        :param real_x:
        :param imag_x:
        :param real_h:
        :param imag_h:
        :param real_noise:
        :param imag_noise:
        :return :
        """
        # complex value of the inputs
        x = tf.complex(real_x, imag_x, name="x")
        h = tf.complex(real_h, imag_h, name="h")
        noise = tf.complex(real_noise, imag_noise, name="noise")

        # build network
        with tf.name_scope('baseband_beamforming'):
            t_bb_output = bt.fully_connected_layer(x, self.db_dim_list, self.db_activation_list)

        with tf.name_scope('power_constrained'):
            real_pc_output, imag_pc_output = bt.power_constrained(t_bb_output, True)
            # power_constrained_output
            pc_output = tf.complex(real_pc_output, imag_pc_output, name="pc_output")

        with tf.name_scope('channel_transmission'):
            # 过传输矩阵H
            h_real_temp = tf.matmul(real_pc_output, real_h, name="RxR") - tf.matmul(imag_pc_output, imag_h, name="IxI")
            h_imag_temp = tf.matmul(real_pc_output, imag_h, name="RxI") + tf.matmul(imag_pc_output, real_h, name="IxR")
            # h_output
            h_output = tf.complex(h_real_temp, h_imag_temp, name="h_output")
        # add noise
        with tf.name_scope("add_noise"):
            real_noise_output = tf.add(h_real_temp, real_noise, name="real")
            imag_noise_output = tf.add(h_imag_temp, imag_noise, name="imag")
            # noise_output
            noise_output = tf.complex(real_noise_output, imag_noise_output, name="noise_output")

        # user0
        user_name = "user" + str(0)
        with tf.name_scope(user_name):
            with tf.name_scope("baseband_combining"):
                r_bb_output = bt.fully_connected_layer(noise_output, self.dc_dim_list, self.dc_activation_list)

        # others
        for user in range(1, self.K):
            user_name = "user" + str(user)
            with tf.name_scope(user_name):
                with tf.name_scope("baseband_combining"):
                    bb_temp = bt.fully_connected_layer(noise_output, self.dc_dim_list, self.dc_activation_list)
                r_bb_output = tf.concat([r_bb_output, bb_temp], 1)

        real_prediction = tf.real(r_bb_output)
        imag_prediction = tf.imag(r_bb_output)

        self.predictions["t_bb_output"] = t_bb_output
        self.predictions["pc_output"] = pc_output
        self.predictions["h_output"] = h_output
        self.predictions["noise_output"] = noise_output
        self.predictions["r_bb_output"] = r_bb_output
        self.predictions["x"] = x
        # self.predictions["h"] = h
        self.predictions["noise"] = noise

        return real_prediction, imag_prediction

    def summary_predictions(self):
        for key in self.predictions:
            tf.summary.scalar("power_" + key, bt.signal_power_tf(self.predictions[key], 0))
            tf.summary.histogram("abs_" + key, tf.reshape(tf.abs(self.predictions[key]), [1, -1]))
        # loss
        tf.summary.scalar("loss", self.loss)

    def loss_fn(self, real_inputs, imag_inputs,  real_labels, imag_labels):
        loss = tf.reduce_mean(tf.square(real_inputs-real_labels) + tf.square(imag_inputs-imag_labels))
        return loss



