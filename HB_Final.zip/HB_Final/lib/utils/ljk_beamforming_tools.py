import tensorflow as tf
from tensorflow.python.framework import ops


def phase_shift_matmul(real_input_signal, imag_input_signal, input_phase, name=None):
    """
    analog phase shift， 矩阵乘法
    :param real_input_signal: baseband signal
    :param imag_input_signal: baseband signal
    :param input_phase: theta
    :param name: name
    :return: (real+imagj)(cos0+sin0j)
           : real = real*cos0 - imag*sin0
           : imag = imag*cos0 + real*sin0
    """
    with tf.name_scope(name):
        real = tf.matmul(real_input_signal, tf.cos(input_phase)) - tf.matmul(imag_input_signal, tf.sin(input_phase))
        imag = tf.matmul(imag_input_signal, tf.cos(input_phase)) + tf.matmul(real_input_signal, tf.sin(input_phase))
    return real, imag


def phase_shift_multiply(input_signal, input_phase, name=None):
    """
    analog phase shift, 对应位置相乘
    :param input_signal: baseband signal
    :param input_phase: theta
    :param name: name
    :return: RF signal = baseband signal * (cos(theta) + 1j*sin(theta))
    """
    return tf.multiply(input_signal, tf.complex(tf.cos(input_phase), tf.sin(input_phase)), name=name)


def power_constrained(real_input_signal, imag_input_signal, constrained=True):
    """
    对输入的信号进行功率约束，约束到 power 大小 ouput_signal = power*(input / signal_power(input_signal))
    :param real_input_signal:
    :param imag_input_signal:
    :param constrained:
    :return: real
           : imag
    """
    if constrained:
        signal_power = tf.reduce_sum(tf.reduce_mean(tf.square(real_input_signal) + tf.square(imag_input_signal), axis=0))
        parameter = tf.sqrt(signal_power)
        real = tf.div(real_input_signal, parameter)
        imag = tf.div(imag_input_signal, parameter)
    else:
        real = real_input_signal
        imag = imag_input_signal

    return real, imag


def signal_power_tf(signal_input, *arg):
    """
    Calculate the power of the input signal, default axis=0
    :param signal_input:
    :param arg:
                arg[0]: axis
    :return: power
    """
    energy = tf.pow(tf.abs(signal_input), 2)
    if len(arg) < 1:
        power = tf.reduce_sum(tf.reduce_mean(energy))
    else:
        power = tf.reduce_sum(tf.reduce_mean(energy, axis=arg[0]))
    return power


def compute_threshold(x):   # 计算三值化的阈值
    # x_max=tf.reduce_max(x,reduce_indices= None, keep_dims= False, name= None)
    x_sum = tf.reduce_sum(tf.abs(x), reduction_indices=None, keep_dims=False, name=None)
    mean = tf.div(x_sum, tf.cast(tf.size(x), tf.float32), name=None)
    threshold = tf.multiply(0.7, mean, name=None)
    return threshold, mean


def ternary_operation(x):   # 对数据进行三值化操作

    """
    Clip and binarize tensor using the straight through estimator (STE) for the gradient.
    """
    g = tf.get_default_graph()

    with ops.name_scope("tenarized") as name:
        with g.gradient_override_map({"Sign": "Identity"}):
            threshold, mean = compute_threshold(x)
            x = mean * tf.sign(tf.add(tf.sign(tf.add(x, threshold)), tf.sign(tf.add(x, -threshold))))
            return x