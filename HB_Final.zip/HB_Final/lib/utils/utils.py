import numpy as np
import lib.utils.SaveAndLoad as Sal


def delta_dict(dict1, dict2):
    """
    delta = dict1 - dict2 字典中相同 key 值的 value 相减
    :param dict1:
    :param dict2:
    :return: delta
    """
    delta = {}
    for key in dict1.keys():
        delta[key] = dict2[key] - dict1[key]
    return delta

#
# dict_1 = Sal.load_pkl("H:\\meta_autoencoder\\data\\QAM\\mimochan\\mimochan0.pkl")
# dict_2 = Sal.load_pkl("H:\\meta_autoencoder\\data\\QAM\\mimochan\\mimochan1.pkl")
# print(type(dict_1))
# print(np.shape(dict_1))
# delta_dict = delta_dict(dict_1, dict_2)
# pass

