import tensorflow as tf
import numpy as np


def complex_matmul(inputs_1, inputs_2, name=None):
    """
    complex matmul
    :param inputs_1:
    :param inputs_2:
    :param name:
    :return: outputs:
    """
    with tf.name_scope(name):
        real_outputs = tf.matmul(tf.real(inputs_1), tf.real(inputs_2)) - tf.matmul(tf.imag(inputs_1), tf.imag(inputs_2))
        imag_outputs = tf.matmul(tf.real(inputs_1), tf.imag(inputs_2)) + tf.matmul(tf.imag(inputs_1), tf.real(inputs_2))
        outputs = tf.complex(real_outputs, imag_outputs)
    return outputs


def partially_beamformer(inputs, inputs_dim, outputs_dim, name=None):
    """
    partially connected beamformer
    :param inputs: inputs signal
    :param inputs_dim: dim of inputs
    :param outputs_dim: dim of outputs
    :param name: name
    :return: outputs:
    """
    n_per = np.int(outputs_dim/inputs_dim)  # 子连接的连接度
    # floor 0
    rf_f0 = phase_shift_matmul(tf.reshape(inputs[:, 0], (-1, 1)), 1, n_per)
    # other floors
    for i in range(1, inputs_dim):
        temp = phase_shift_matmul(tf.reshape(inputs[:, i], (-1, 1)), 1, n_per)
        rf_f0 = tf.concat([rf_f0, temp], 1)  # concat
    outputs = rf_f0
    return outputs


def fully_beamformer(inputs, inputs_dim, outputs_dim, name=None):
    """
    fully connected beamformer
    :param inputs:
    :param inputs_dim:
    :param outputs_dim:
    :param name:
    :return:
    """
    outputs = phase_shift_matmul(inputs, inputs_dim, outputs_dim)
    return outputs


def partially_combiner(inputs, inputs_dim, outputs_dim, name=None):
    """
    partially connected combiner
    :param inputs:
    :param inputs_dim:
    :param outputs_dim:
    :param name:
    :return:
    """
    n_per = np.int(inputs_dim / outputs_dim)  # 子连接的连接度
    # floor 0
    rf_f0 = phase_shift_matmul(tf.reshape(inputs[:, 0*n_per:1*n_per], (-1, n_per)), n_per, 1)
    # others
    for i in range(1, outputs_dim):
        temp = phase_shift_matmul(tf.reshape(inputs[:, i*n_per:(i+1)*n_per], (-1, n_per)), n_per, 1)
        rf_f0 = tf.concat([rf_f0, temp], 1)  # concat
    outputs = rf_f0
    return outputs


def fully_combiner(inputs, inputs_dim, outputs_dim, name=None):
    """
    fully connected beamformer
    :param inputs:
    :param inputs_dim:
    :param outputs_dim:
    :param name:
    :return:
    """
    outputs = phase_shift_matmul(inputs, inputs_dim, outputs_dim)
    return outputs


def complex_dense(inputs, inputs_dim, outputs_dim, activation=None, name=None):
    """
    complex_64 dense layer
    :param inputs: input complex signal(data type complex_64)
    :param inputs_dim: dim of inputs
    :param outputs_dim: dim of outputs
    :param activation: activation function
    :param name: name
    :return: outputs: O = a(I * W + b)
    """
    with tf.name_scope(name):
        # 定义变量
        # weights
        real_w = tf.Variable(tf.truncated_normal([inputs_dim, outputs_dim], stddev=0.01))
        imag_w = tf.Variable(tf.truncated_normal([inputs_dim, outputs_dim], stddev=0.01))
        w = tf.complex(real_w, imag_w, name="weights")
        # biases
        real_b = tf.Variable(tf.zeros([outputs_dim]))
        imag_b = tf.Variable(tf.zeros([outputs_dim]))
        b = tf.complex(real_b, imag_b, name="biases")
        # matmul (complex matmul)
        temp = complex_matmul(inputs, w) + b  # complex matmul self
        # temp = tf.matmul(inputs, w) + b  # tf.matmul
        # activation function
        if activation is None:
            outputs = temp
        else:
            outputs = tf.complex(activation(tf.real(temp)), activation(tf.imag(temp)))
        return outputs


def fully_connected_layer(inputs, num_list, activation_list):
    """
    fully connected layer
    :param inputs:
    :param num_list:
    :param activation_list:
    :return:
    """
    dim_l0 = inputs.get_shape().as_list()[-1]  # get the dim of input signals
    # layer_0
    temp = complex_dense(inputs, dim_l0, num_list[0], activation_list[0], name="layer_0")
    # other layers
    for i in range(1, len(num_list)):
        temp = complex_dense(temp, num_list[i-1], num_list[i], activation_list[i], name="layer_"+str(i))
    outputs = temp
    return outputs


def phase_shift_matmul(inputs, inputs_dim, outputs_dim, name=None):
    """
    analog phase shift， 矩阵乘法
    :param inputs:
    :param inputs_dim:
    :param outputs_dim:
    :param name: name
    :return: (real+imagj)(cos0+sin0j)
           : real = real*cos0 - imag*sin0
           : imag = imag*cos0 + real*sin0
    """

    theta_r = tf.Variable(tf.random_uniform([inputs_dim, outputs_dim], minval=0, maxval=2 * np.pi))
    with tf.name_scope(name):
        real = tf.matmul(tf.real(inputs), tf.cos(theta_r)) - tf.matmul(tf.imag(inputs), tf.sin(theta_r))
        imag = tf.matmul(tf.imag(inputs), tf.cos(theta_r)) + tf.matmul(tf.real(inputs), tf.sin(theta_r))
    outputs = tf.complex(real, imag)
    return outputs

    # with tf.name_scope(name):
    #     # 初始化相位参数
    #     theta = tf.Variable(tf.random_uniform([inputs_dim, outputs_dim], minval=0, maxval=2 * np.pi))
    #     theta_complex = tf.complex(tf.cos(theta), tf.sin(theta))  # 转变为复数
    #     outputs = complex_matmul(inputs, theta_complex)  # complex_matmul self
    #     # outputs = tf.matmul(inputs, theta_complex)  # tf.matmul
    #
    #     return outputs


def phase_shift_multiply(input_signal, input_phase, name=None):
    """
    analog phase shift, 对应位置相乘
    :param input_signal: baseband signal
    :param input_phase: theta
    :param name: name
    :return: RF signal = baseband signal * (cos(theta) + 1j*sin(theta))
    """
    return tf.multiply(input_signal, tf.complex(tf.cos(input_phase), tf.sin(input_phase)), name=name)


def power_constrained(inputs, constrained=True):
    """
    对输入的信号进行功率约束，约束到 power 大小 ouput_signal = power*(input / signal_power(input_signal))
    :param inputs:
    :param constrained:
    :return: real
           : imag
    """
    real_input_signal = tf.real(inputs)
    imag_input_signal = tf.imag(inputs)
    if constrained:
        signal_power = tf.reduce_sum(tf.reduce_mean(tf.square(real_input_signal) + tf.square(imag_input_signal), axis=0))
        parameter = tf.sqrt(signal_power)
        real = tf.div(real_input_signal, parameter)
        imag = tf.div(imag_input_signal, parameter)
    else:
        real = real_input_signal
        imag = imag_input_signal

    return real, imag


def signal_power_tf(signal_input, *arg):
    """
    Calculate the power of the input signal, default axis=0
    :param signal_input:
    :param arg:
                arg[0]: axis
    :return: power
    """
    energy = tf.pow(tf.abs(signal_input), 2)
    if len(arg) < 1:
        power = tf.reduce_sum(tf.reduce_mean(energy))
    else:
        power = tf.reduce_sum(tf.reduce_mean(energy, axis=arg[0]))
    return power


def get_analog_beamformer(model, result):
    """
    get analog beamformer
    :return: Frf
    """
    theta_t = np.zeros((model.Ns_total, model.Nt), dtype=np.float32)
    Frf = np.zeros((model.Ns_total, model.Nt), dtype=np.complex64)

    t = np.squeeze(result["rf_beamforming/Variable:0"])
    theta_t[0, 0:model.t_per] = t
    complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in t])[np.newaxis, :]
    Frf[0, 0:model.t_per] = complex_temp
    for index in range(1, model.Ns_total):
        t = np.squeeze(result["rf_beamforming/Variable_" + str(index) + ":0"])
        theta_t[index, index * model.t_per: (index + 1) * model.t_per] = t
        complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in t])[np.newaxis, :]
        Frf[index, index * model.t_per: (index + 1) * model.t_per] = complex_temp
    return Frf


def get_analog_combiner(model, result):
    """
    get analog combiner
    :param model:
    :param result:
    :return: Wrf
    """
    theta_r = np.zeros((model.Nr_total, model.Ntrf), dtype=np.float32)
    Wrf = np.zeros((model.Nr_total, model.Ntrf), dtype=np.complex64)

    for user in range(model.K):
        r = np.squeeze(result["user" + str(user) + "/rf_combining/Variable:0"])
        theta_r[user * model.Nr:user * model.Nr + model.r_per, user * model.Ns] = r
        complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in r])[np.newaxis, :]
        Wrf[user * model.Nr:user * model.Nr + model.r_per, user * model.Ns] = complex_temp
        if model.Ns != 1:
            for i in range(1, model.Ns):
                r = np.squeeze(result["user" + str(user) + "/rf_combining/Variable_" + str(i) + ":0"])
                theta_r[user * model.Nr + i * model.r_per:user * model.Nr + (i + 1) * model.r_per, user * model.Ns + i] = r
                complex_temp = np.array([np.complex(np.cos(theta), np.sin(theta)) for theta in r])[np.newaxis, :]
                Wrf[user * model.Nr + i * model.r_per:user * model.Nr + (i + 1) * model.r_per, user * model.Ns + i] = complex_temp
    return Wrf