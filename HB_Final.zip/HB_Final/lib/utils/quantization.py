import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# # 设置图例并且设置图例的字体及大小
# font1 = {'family': 'Times New Roman', 'weight': 'normal', 'size': 16}
# # 设置横纵坐标的名称以及对应字体格式
# font2 = {'family': 'Times New Roman', 'weight': 'normal', 'size': 20}


# class Quantization:
#     def __init__(self, parts):
#         self.parts = parts
#         self.quadrant_list = self.construct_quadrant()
#
#     def quantificat(self, inputs):
#         shape = tf.shape(inputs)      # 得到需要量化的维度
#         temp = []
#         distance_list = []
#         norm_input = tf.mod(inputs, 2 * np.pi)   # 相对2pi得到余数
#         input_reshape = tf.reshape(norm_input, [-1])   # 整形成一行
#         m = input_reshape.get_shape().as_list()
#
#         quant_tensor = tf.convert_to_tensor(self.quadrant_list)
#         quant_tensor_reshape = tf.reshape(quant_tensor, [-1])
#         p = quant_tensor_reshape.get_shape().as_list()
#
#         for i in range(m[0]):
#             print(i)
#             for j in range(p[0]):
#                 distance_list.append(tf.abs(tf.subtract(input_reshape[i], quant_tensor_reshape[j])))
#             index = tf.argmin(distance_list)
#             temp.append(quant_tensor_reshape[index])
#
#         outputs = tf.reshape(temp, shape)
#
#         # # plt
#         # plt.figure(1)
#         # plt_x = list(range(len(input_reshape)))
#         # plt.scatter(plt_x, input_reshape, label="original", linewidth=2.0)
#         # plt.scatter(plt_x, temp, label="quantization", linewidth=2.0)
#         # plt.grid()
#         # plt.tick_params(labelsize=16)
#         # plt.xlabel("num", font2)
#         # plt.ylabel("angle", font2)
#         # plt.legend(prop=font1)
#         # plt.show()
#         return outputs
#
#     def construct_quadrant(self):
#         quadrant_list = []
#         per = (2 * np.pi) / self.parts      # 精度间隔
#         for index in range(self.parts):
#             quadrant_value = index * per + per / 2
#             quadrant_list.append(quadrant_value)
#
#         return quadrant_list
class Quantization:
    def __init__(self, parts):
        self.parts = parts
        self.quadrant_list = self.construct_quadrant()

    def quantificat(self, inputs):
        shape = tf.shape(inputs)
        temp = []
        norm_inputs = tf.mod(inputs, 2 * np.pi)
        inputs_reshape = tf.reshape(norm_inputs, [-1])
        m = inputs_reshape.get_shape().as_list()
        for i in range(m[0]):
            distance_list = tf.abs(tf.subtract(inputs_reshape[i], self.quadrant_list))
            index = tf.argmin(distance_list)
            temp.append(self.quadrant_list[index])
        outputs = tf.reshape(temp, shape)

        # # plt
        # plt.figure(1)
        # plt_x = list(range(len(inputs_reshape)))
        # plt.scatter(plt_x, inputs_reshape, label="original", linewidth=2.0)
        # plt.scatter(plt_x, temp, label="quantization", linewidth=2.0)
        # plt.grid()
        # plt.tick_params(labelsize=16)
        # plt.xlabel("num", font2)
        # plt.ylabel("angle", font2)
        # plt.legend(prop=font1)
        # plt.show()
        return outputs

    def construct_quadrant(self):
        quadrant_list = []
        per = (2 * np.pi) / self.parts
        for index in range(self.parts):
            quadrant_value = index * per + per / 2
            quadrant_list.append(quadrant_value)
            # quadrant_key = "quadrant" + str(index)
            # quadrant_dict[quadrant_key] = quadrant_value

        return tf.reshape(quadrant_list, [-1])
