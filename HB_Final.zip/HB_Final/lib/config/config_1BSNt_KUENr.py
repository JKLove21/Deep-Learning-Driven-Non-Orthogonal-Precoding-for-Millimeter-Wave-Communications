import tensorflow as tf
import lib.utils.SaveAndLoad as Sal
import os


FLAGS = tf.app.flags.FLAGS

# simulation parameters
tf.app.flags.DEFINE_string('modulation_mode', "QAM", 'modulation model')
tf.app.flags.DEFINE_string("power_normalization", "power_normalization_to_1/Ns", 'normalization mode') # power_normalization_to_1 or power_normalization_to_1/Ns
tf.app.flags.DEFINE_integer('K', 1, 'number of users')
tf.app.flags.DEFINE_integer('Ns', 2, 'number of data streams per user')
tf.app.flags.DEFINE_integer('Nrrf', 2, 'number of receive RF chains per user')
tf.app.flags.DEFINE_integer('Ntrf', 2, 'number of receive RF chains per user')
tf.app.flags.DEFINE_integer('Nr', 64, 'number of receive antennas per user')
tf.app.flags.DEFINE_integer('Nt', 64, 'number of antenna at transmitter')

# connected structure
tf.app.flags.DEFINE_string('connected', "partially", 'partially or fully connected structure for phase shifter network') # partially or fully

#
tf.app.flags.DEFINE_integer('print_steps', 1000, 'number of steps for print')
tf.app.flags.DEFINE_integer('N_inter', 5, '插值数')
tf.app.flags.DEFINE_integer('N_gap', 1, 'delta n')

# model parameters
tf.app.flags.DEFINE_float('lr', 0.001, 'learning rate')
tf.app.flags.DEFINE_integer('num_training', 10000, "number of training times")
tf.app.flags.DEFINE_integer('N_bits_test', 64000, "number of bits during test")
tf.app.flags.DEFINE_integer('N_iter', 1000, "number of iteration")
tf.app.flags.DEFINE_integer('snr_training', -5, "SNR for training")
tf.app.flags.DEFINE_integer('batch_size', 128, "Network batch size during training")
tf.app.flags.DEFINE_integer('step_size', 10000, "Step size for reducing the learning rate, currently only support one step")

# path
path1 = "C:/Users/supreme ljk/Desktop/HB_Final"
tf.app.flags.DEFINE_string('logdir', path1+"data/logdir", 'path for saving model')
tf.app.flags.DEFINE_string('path_for_hsets', path1+"data/hsets.pkl", 'path for hsets')
tf.app.flags.DEFINE_string('path_for_batch_x', path1+"signal_gen", 'path for hsets')
tf.app.flags.DEFINE_string('path_for_ber', path1+"/ber.pkl", 'path for ber')
tf.app.flags.DEFINE_string('store_data_pre', path1 + "/pretrained_data/logdir", 'path for saving model')

# loading saving and testing options
tf.app.flags.DEFINE_bool('resume', True, 'resume training if there is a model available')
tf.app.flags.DEFINE_bool('q_resume', False, 'False 覆盖')
tf.app.flags.DEFINE_bool('train', True, 'True to train, False to test.')
tf.app.flags.DEFINE_bool('test', True, 'True to train, False to test.')
tf.app.flags.DEFINE_bool('log', True, 'if false, do not log summaries, for debugging code.')
tf.app.flags.DEFINE_bool('h_select', False, 'if false, choose interpolation channel matrix.')

# 变学习率+使用预训练模型
tf.app.flags.DEFINE_bool('pretrained_data_select', False, 'if true, choose the pretrained data as start.')
tf.app.flags.DEFINE_bool('pretrained_data_store', False, 'if true, store the pretrained data in directory: pretrained_data.')
tf.app.flags.DEFINE_bool('lr_change', False, 'if true, choose the changing lr.')
tf.app.flags.DEFINE_bool('constrained', True, 'if true, choose the trained weight.')

# 量化模型
path = "data_quant"
tf.app.flags.DEFINE_string('path', path, 'path')
tf.app.flags.DEFINE_string('path_for_ber_quant', path + "/ber.pkl", 'path for ber')
tf.app.flags.DEFINE_string('path_for_hsets_quant', path + "/hsets.pkl", 'path for hsets')
tf.app.flags.DEFINE_string('path_for_results', path + "/results.pkl", 'path for results')
tf.app.flags.DEFINE_string('quant_mode', "original", 'quant mode')
tf.app.flags.DEFINE_string('angle', "pi_3", 'quant angle')
tf.app.flags.DEFINE_bool('quantization', True, 'if True,quantization')
tf.app.flags.DEFINE_bool('quantization_training', True, 'if True,quantization,and training')
tf.app.flags.DEFINE_bool('quantization_test', True, 'if True,quantization,and test')
tf.app.flags.DEFINE_integer('num_q_training', 8000, "number of quantization training times")
tf.app.flags.DEFINE_bool('parameter_select', True, 'if True,select parameter from model stored')




