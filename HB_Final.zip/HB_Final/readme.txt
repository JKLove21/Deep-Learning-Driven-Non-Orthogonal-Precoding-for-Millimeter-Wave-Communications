The code is for the paper entitled "Deep Learning Driven Non-Orthogonal Precoding for Millimeter Wave Communications"

The simulation can be run in main fuction

The mm-Wave channel can be checked in "channel_generation.m"